import { NextRequest } from "next/server";
import { buildSession } from "@/lib/quiz/engine";
import { QUIZ_SIZE, type Mode } from "@/lib/categories";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  let body: { cat?: string; mode?: string; exclude?: unknown; count?: number } = {};
  try {
    body = await req.json();
  } catch {
    // empty body is fine
  }
  const cat = typeof body.cat === "string" ? body.cat : "qarisiq";
  const mode: Mode = body.mode === "kids" ? "kids" : "adult";
  const exclude = Array.isArray(body.exclude) ? body.exclude.filter((x): x is string => typeof x === "string").slice(0, 500) : [];
  const count = Math.min(Math.max(Number(body.count) || QUIZ_SIZE, 3), 15);

  const session = buildSession({ cat, mode, count, exclude });
  return Response.json(session, { headers: { "Cache-Control": "no-store" } });
}
