import { NextRequest } from "next/server";
import { db } from "@/db";
import { results, players } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    const playerId = String(b.playerId ?? "").slice(0, 64);
    const section = String(b.section ?? "").slice(0, 40);
    const kind = b.kind === "game" ? "game" : "quiz";
    const total = Math.max(0, Math.min(Number(b.total) || 0, 1000));
    const score = Math.max(0, Math.min(Number(b.score) || 0, total || 1000));
    const xp = Math.max(0, Math.min(Number(b.xp) || 0, 500));
    if (playerId.length < 8 || !section) return Response.json({ ok: false }, { status: 400 });

    await db.insert(results).values({ playerId, section, kind, score, total, xp });
    await db
      .update(players)
      .set({ xp: sql`${players.xp} + ${xp}`, updatedAt: new Date() })
      .where(eq(players.id, playerId));
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
