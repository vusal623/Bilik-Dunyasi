import { NextRequest } from "next/server";
import { db } from "@/db";
import { reports } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    const questionId = String(b.questionId ?? "").slice(0, 80);
    const questionText = String(b.questionText ?? "").slice(0, 600);
    const note = b.note ? String(b.note).slice(0, 400) : null;
    const playerId = b.playerId ? String(b.playerId).slice(0, 64) : null;
    if (!questionId || !questionText) return Response.json({ ok: false }, { status: 400 });
    await db.insert(reports).values({ questionId, questionText, note, playerId });
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
