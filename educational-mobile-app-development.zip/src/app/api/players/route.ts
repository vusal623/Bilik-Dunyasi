import { NextRequest } from "next/server";
import { db } from "@/db";
import { players } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    const id = String(b.id ?? "").slice(0, 64);
    const name = String(b.name ?? "").trim().slice(0, 24) || "Oyunçu";
    const avatar = String(b.avatar ?? "🦊").slice(0, 8);
    const mode = b.mode === "kids" ? "kids" : "adult";
    const xp = Math.max(0, Math.min(Number(b.xp) || 0, 10_000_000));
    if (id.length < 8) return Response.json({ ok: false }, { status: 400 });

    await db
      .insert(players)
      .values({ id, name, avatar, mode, xp })
      .onConflictDoUpdate({
        target: players.id,
        set: { name, avatar, mode, xp: sql`GREATEST(${players.xp}, ${xp})`, updatedAt: new Date() },
      });
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
