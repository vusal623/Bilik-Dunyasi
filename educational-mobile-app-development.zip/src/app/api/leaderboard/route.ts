import { db } from "@/db";
import { players } from "@/db/schema";
import { desc, gt } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select({ id: players.id, name: players.name, avatar: players.avatar, xp: players.xp, mode: players.mode })
      .from(players)
      .where(gt(players.xp, 0))
      .orderBy(desc(players.xp))
      .limit(20);
    // do not leak full ids: only a short hash-like suffix to let a client identify itself
    return Response.json({
      rows: rows.map((r) => ({ key: r.id.slice(-6), name: r.name, avatar: r.avatar, xp: r.xp, mode: r.mode })),
    });
  } catch {
    return Response.json({ rows: [] });
  }
}
