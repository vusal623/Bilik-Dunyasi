"use client";

import Link from "next/link";
import { CATEGORIES } from "@/lib/categories";
import { remaining, usedToday, useStore } from "@/lib/store";
import { PageHeader } from "@/components/ui";

export default function TestsPage() {
  const { ready, p } = useStore();
  return (
    <div>
      <PageHeader title="Testlər" subtitle="Fənn seç və biliyini yoxla" emoji="📝" />
      <div className="grid grid-cols-2 gap-3 p-4">
        {CATEGORIES.map((c, i) => {
          const left = ready && p ? remaining(p, c.id) : null;
          const done = ready && p ? usedToday(p, c.id) : 0;
          const locked = left !== null && left === 0;
          const st = ready && p ? p.stats[c.id] : undefined;
          const pct = st && st.t ? Math.round((st.c / st.t) * 100) : null;
          return (
            <Link
              key={c.id}
              href={`/quiz/${c.id}`}
              style={{ animationDelay: `${i * 40}ms` }}
              className={`anim-up relative overflow-hidden rounded-3xl bg-gradient-to-br ${c.gradient} p-4 text-white shadow-md active:scale-95 ${c.id === "qarisiq" ? "col-span-2" : ""} ${locked ? "opacity-60 grayscale-[40%]" : ""}`}
            >
              <div className="absolute -right-3 -top-3 text-7xl opacity-20">{c.emoji}</div>
              <div className="text-4xl">{c.emoji}</div>
              <div className="mt-2 text-lg font-extrabold">{c.name}</div>
              <div className="text-xs text-white/85">{c.desc}</div>
              <div className="mt-3 flex items-center justify-between text-[11px] font-bold">
                <span className="rounded-full bg-white/25 px-2 py-0.5">
                  {locked ? "🔒 Limit doldu" : left === null ? "Limitsiz" : `${left} sessiya qalıb`}
                </span>
                {pct !== null && <span className="rounded-full bg-white/25 px-2 py-0.5">{pct}% düz.</span>}
              </div>
              {ready && p && p.limit > 0 && (
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/25">
                  <div className="h-full rounded-full bg-white" style={{ width: `${Math.min(100, (done / p.limit) * 100)}%` }} />
                </div>
              )}
            </Link>
          );
        })}
      </div>
      <p className="px-6 pb-4 text-center text-xs text-slate-500">
        💡 Suallar hər dəfə dəyişir: görmədiyin suallar əvvəlcə gəlir, riyaziyyat və məntiq sualları isə hər dəfə yenidən yaradılır.
      </p>
    </div>
  );
}
