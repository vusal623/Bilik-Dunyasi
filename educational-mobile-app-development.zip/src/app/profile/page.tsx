"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { CATEGORIES, type Mode } from "@/lib/categories";
import { computeBadges, dayKey, resetAll, updateProfile, useStore, usedToday, xpForLevel } from "@/lib/store";
import { Card, PageHeader } from "@/components/ui";

const AVATARS = ["🦊", "🐼", "🦁", "🐯", "🐸", "🦄", "🐙", "🦉", "🐧", "🐬", "🚀", "🧙"];
const LIMITS = [3, 5, 10, 0];
const WD = ["B", "B.e", "Ç.a", "Çər", "C.a", "Cüm", "Şən"];

function ParentGate({ onPass, onCancel }: { onPass: () => void; onCancel: () => void }) {
  const [a] = useState(() => 12 + Math.floor(Math.random() * 8));
  const [b] = useState(() => 6 + Math.floor(Math.random() * 4));
  const [v, setV] = useState("");
  const [bad, setBad] = useState(false);
  return (
    <div className={`mt-3 rounded-2xl bg-amber-50 p-4 ring-1 ring-amber-200 ${bad ? "anim-shake" : ""}`}>
      <div className="text-sm font-extrabold text-amber-800">👨‍👩‍👧 Valideyn yoxlaması</div>
      <div className="mt-1 text-sm text-amber-700">Bu ayarı dəyişmək üçün cavab ver: <b>{a} × {b} = ?</b></div>
      <div className="mt-2 flex gap-2">
        <input
          value={v}
          onChange={(e) => setV(e.target.value.replace(/\D/g, ""))}
          inputMode="numeric"
          className="w-24 rounded-xl border-2 border-amber-200 bg-white px-3 py-2 font-bold outline-none"
        />
        <button
          onClick={() => {
            if (Number(v) === a * b) onPass();
            else {
              setBad(true);
              setTimeout(() => setBad(false), 500);
            }
          }}
          className="rounded-xl bg-amber-500 px-4 py-2 font-bold text-white"
        >
          Təsdiq et
        </button>
        <button onClick={onCancel} className="rounded-xl px-3 py-2 text-sm font-semibold text-amber-700">Ləğv et</button>
      </div>
    </div>
  );
}

export default function ProfilePage() {
  const { ready, p } = useStore();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState("");
  const [gate, setGate] = useState<null | { run: () => void }>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  const week = useMemo(() => {
    const out: { key: string; label: string; c: number; t: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = dayKey(d);
      out.push({ key, label: WD[d.getDay()], c: p?.days[key]?.c ?? 0, t: p?.days[key]?.t ?? 0 });
    }
    return out;
  }, [p]);

  if (!ready || !p) return <div className="flex min-h-[60dvh] items-center justify-center text-5xl anim-float">👤</div>;

  const { level, into } = xpForLevel(p.xp);
  const totalC = Object.values(p.stats).reduce((a, s) => a + s.c, 0);
  const totalT = Object.values(p.stats).reduce((a, s) => a + s.t, 0);
  const acc = totalT ? Math.round((totalC / totalT) * 100) : 0;
  const maxDay = Math.max(5, ...week.map((w) => w.t));
  const badges = computeBadges(p);
  const earned = badges.filter((b) => b.earned).length;
  const todayTotal = Object.values(p.daily.sessions).reduce((a, b) => a + b, 0);

  const guarded = (run: () => void) => {
    if (p.mode === "kids") setGate({ run });
    else run();
  };

  return (
    <div>
      <PageHeader title="Profilim" subtitle={`Səviyyə ${level} • ${p.xp} XP`} emoji={p.avatar} />

      <div className="space-y-4 p-4">
        <Card>
          <div className="flex items-center justify-between">
            {editing ? (
              <div className="flex flex-1 items-center gap-2">
                <input value={name} onChange={(e) => setName(e.target.value)} maxLength={20} className="min-w-0 flex-1 rounded-xl border-2 border-violet-200 px-3 py-2 font-bold outline-none" />
                <button
                  onClick={() => {
                    if (name.trim()) updateProfile({ name: name.trim() });
                    setEditing(false);
                  }}
                  className="rounded-xl bg-violet-600 px-4 py-2 font-bold text-white"
                >
                  Saxla
                </button>
              </div>
            ) : (
              <>
                <div>
                  <div className="text-xl font-extrabold text-violet-900">{p.name}</div>
                  <div className="text-xs text-slate-500">{p.mode === "kids" ? "🧒 Uşaq rejimi" : "🧑 Böyük rejimi"}</div>
                </div>
                <button
                  onClick={() => {
                    setName(p.name);
                    setEditing(true);
                  }}
                  className="rounded-xl bg-violet-50 px-3 py-2 text-sm font-bold text-violet-700"
                >
                  ✏️ Dəyiş
                </button>
              </>
            )}
          </div>
          <div className="mt-3 grid grid-cols-6 gap-2">
            {AVATARS.map((a) => (
              <button key={a} onClick={() => updateProfile({ avatar: a })} className={`aspect-square rounded-xl text-xl ${p.avatar === a ? "bg-violet-600 shadow" : "bg-violet-50"}`}>
                {a}
              </button>
            ))}
          </div>
          <div className="mt-4 h-3 overflow-hidden rounded-full bg-violet-100">
            <div className="h-full rounded-full bg-gradient-to-r from-violet-500 to-pink-500" style={{ width: `${into}%` }} />
          </div>
          <div className="mt-1 text-xs text-slate-500">Növbəti səviyyəyə {100 - into} XP qalıb</div>
        </Card>

        <div className="grid grid-cols-3 gap-3 text-center">
          <Card className="!p-3"><div className="text-2xl">🔥</div><div className="text-xl font-extrabold">{p.streak}</div><div className="text-[11px] text-slate-500">gün seriya</div></Card>
          <Card className="!p-3"><div className="text-2xl">🎯</div><div className="text-xl font-extrabold">{acc}%</div><div className="text-[11px] text-slate-500">düzgünlük</div></Card>
          <Card className="!p-3"><div className="text-2xl">✅</div><div className="text-xl font-extrabold">{totalC}</div><div className="text-[11px] text-slate-500">düzgün cavab</div></Card>
        </div>

        <Card>
          <h2 className="font-extrabold text-violet-900">Son 7 gün</h2>
          <p className="text-xs text-slate-500">Cavablanmış sual sayı (yaşıl hissə — düzgün)</p>
          <div className="mt-3 flex h-32 items-end justify-between gap-2">
            {week.map((w) => (
              <div key={w.key} className="flex flex-1 flex-col items-center justify-end gap-1">
                <div className="text-[10px] font-bold text-slate-400">{w.t || ""}</div>
                <div className="flex w-full flex-col justify-end overflow-hidden rounded-t-lg bg-violet-100" style={{ height: `${Math.max(4, (w.t / maxDay) * 90)}px` }}>
                  <div className="bg-emerald-400" style={{ height: `${w.t ? (w.c / w.t) * 100 : 0}%` }} />
                </div>
                <div className={`text-[10px] font-bold ${w.key === dayKey() ? "text-violet-700" : "text-slate-400"}`}>{w.label}</div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <h2 className="font-extrabold text-violet-900">Fənlər üzrə nəticələr</h2>
          <div className="mt-3 space-y-3">
            {CATEGORIES.map((c) => {
              const s = p.stats[c.id];
              const pct = s && s.t ? Math.round((s.c / s.t) * 100) : 0;
              return (
                <div key={c.id}>
                  <div className="flex justify-between text-sm font-bold">
                    <span>{c.emoji} {c.name}</span>
                    <span className="text-slate-500">{s && s.t ? `${pct}% (${s.c}/${s.t})` : "—"}</span>
                  </div>
                  <div className="mt-1 h-2.5 overflow-hidden rounded-full bg-slate-100">
                    <div className={`h-full rounded-full bg-gradient-to-r ${c.gradient}`} style={{ width: `${pct}%`, transition: "width 0.6s" }} />
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <h2 className="font-extrabold text-violet-900">Nailiyyətlər</h2>
            <span className="text-xs font-bold text-slate-500">{earned}/{badges.length}</span>
          </div>
          <div className="mt-3 grid grid-cols-4 gap-2">
            {badges.map((b) => (
              <div key={b.id} title={b.desc} className={`rounded-2xl p-2 text-center ${b.earned ? "bg-amber-50 ring-1 ring-amber-200" : "bg-slate-50 opacity-50"}`}>
                <div className={`text-3xl ${b.earned ? "" : "grayscale"}`}>{b.emoji}</div>
                <div className="mt-1 text-[10px] font-bold leading-tight">{b.name}</div>
              </div>
            ))}
          </div>
          <p className="mt-2 text-[11px] text-slate-400">Nailiyyətin üzərində izahı görmək üçün saxla (və ya aşağıdakı siyahıya bax):</p>
          <ul className="mt-1 space-y-0.5 text-[11px] text-slate-500">
            {badges.map((b) => (
              <li key={b.id}>{b.earned ? "✅" : "⬜"} {b.name} — {b.desc}</li>
            ))}
          </ul>
        </Card>

        <Card>
          <h2 className="font-extrabold text-violet-900">⚙️ Ayarlar</h2>

          <div className="mt-3 text-sm font-bold text-slate-700">Gündəlik limit (hər bölmə üçün sessiya sayı)</div>
          <p className="text-xs text-slate-500">Bu gün tamamlanmış sessiya: {todayTotal}. Hər fənn və oyun üçün ayrıca hesablanır. Limit dolduqda uşaq başqa bölməyə yönləndirilir.</p>
          <div className="mt-2 grid grid-cols-4 gap-2">
            {LIMITS.map((l) => (
              <button
                key={l}
                onClick={() => guarded(() => updateProfile({ limit: l }))}
                className={`rounded-xl py-2.5 text-sm font-extrabold ${p.limit === l ? "bg-violet-600 text-white" : "bg-violet-50 text-violet-700"}`}
              >
                {l === 0 ? "Limitsiz" : l}
              </button>
            ))}
          </div>
          <div className="mt-2 text-xs text-slate-400">
            {CATEGORIES.slice(0, 3).map((c) => `${c.name}: ${usedToday(p, c.id)}`).join(" • ")} …
          </div>

          <div className="mt-4 text-sm font-bold text-slate-700">Rejim</div>
          <div className="mt-2 grid grid-cols-2 gap-2">
            {(["kids", "adult"] as Mode[]).map((m) => (
              <button
                key={m}
                onClick={() => (m === p.mode ? null : guarded(() => updateProfile({ mode: m })))}
                className={`rounded-xl py-2.5 text-sm font-extrabold ${p.mode === m ? "bg-pink-500 text-white" : "bg-pink-50 text-pink-600"}`}
              >
                {m === "kids" ? "🧒 Uşaq" : "🧑 Böyük"}
              </button>
            ))}
          </div>

          {gate && (
            <ParentGate
              onPass={() => {
                gate.run();
                setGate(null);
              }}
              onCancel={() => setGate(null)}
            />
          )}

          <div className="mt-5 border-t border-slate-100 pt-4">
            {confirmReset ? (
              <div className="rounded-2xl bg-rose-50 p-3 text-sm">
                <div className="font-bold text-rose-700">Bütün irəliləyiş silinəcək. Əminsən?</div>
                <div className="mt-2 flex gap-2">
                  <button onClick={() => resetAll()} className="rounded-xl bg-rose-600 px-4 py-2 font-bold text-white">Bəli, sil</button>
                  <button onClick={() => setConfirmReset(false)} className="rounded-xl bg-white px-4 py-2 font-bold text-slate-600">Ləğv et</button>
                </div>
              </div>
            ) : (
              <button onClick={() => guarded(() => setConfirmReset(true))} className="text-sm font-semibold text-rose-500 underline">Bütün məlumatları sıfırla</button>
            )}
          </div>
        </Card>

        <Link href="/leaderboard" className="block rounded-3xl bg-gradient-to-r from-amber-400 to-orange-500 p-4 text-center font-extrabold text-white shadow-md">🏅 Liderlər cədvəlinə bax</Link>
      </div>
    </div>
  );
}
