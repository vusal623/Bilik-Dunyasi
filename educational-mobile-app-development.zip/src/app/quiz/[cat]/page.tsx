import { notFound } from "next/navigation";
import { CATEGORY_MAP } from "@/lib/categories";
import QuizRunner from "@/components/QuizRunner";

export default async function QuizPage({ params }: { params: Promise<{ cat: string }> }) {
  const { cat } = await params;
  if (!CATEGORY_MAP[cat]) notFound();
  return <QuizRunner cat={cat} />;
}
