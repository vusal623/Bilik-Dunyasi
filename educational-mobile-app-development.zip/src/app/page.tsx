"use client";

import Link from "next/link";
import { CATEGORIES, GAMES } from "@/lib/categories";
import { factOfTheDay } from "@/lib/content";
import { remaining, usedToday, useStore, xpForLevel, dayKey } from "@/lib/store";
import { Card, Ring } from "@/components/ui";

const DAILY_GOAL = 3;

export default function Home() {
  const { ready, p } = useStore();
  if (!ready || !p) {
    return <div className="flex min-h-[60dvh] items-center justify-center text-5xl anim-float">🧠</div>;
  }

  const { level, into } = xpForLevel(p.xp);
  const todayCount = p.daily.date === dayKey() ? Object.values(p.daily.sessions).reduce((a, b) => a + b, 0) : 0;
  const fact = factOfTheDay();
  const hour = new Date().getHours();
  const greet = hour < 5 ? "Gecən xeyrə" : hour < 12 ? "Sabahın xeyir" : hour < 18 ? "Salam" : "Axşamın xeyir";
  const streakActive = p.lastDay === dayKey() || p.streak > 0;

  return (
    <div>
      <section className="rounded-b-[2rem] bg-gradient-to-br from-violet-600 via-fuchsia-600 to-pink-500 px-5 pb-8 pt-8 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/25 text-3xl">{p.avatar}</div>
            <div>
              <div className="text-sm text-violet-100">{greet},</div>
              <div className="text-xl font-extrabold leading-tight">{p.name}!</div>
            </div>
          </div>
          <div className="flex items-center gap-1 rounded-full bg-white/20 px-3 py-1.5 text-sm font-extrabold">
            <span className={streakActive ? "" : "grayscale"}>🔥</span> {p.streak}
          </div>
        </div>

        <div className="mt-5 flex items-center gap-4 rounded-3xl bg-white/15 p-4">
          <Ring value={Math.min(1, todayCount / DAILY_GOAL)} color="#fde047">
            <div>
              <div className="text-lg font-extrabold leading-none">{Math.min(todayCount, DAILY_GOAL)}/{DAILY_GOAL}</div>
            </div>
          </Ring>
          <div className="flex-1">
            <div className="font-extrabold">Gündəlik hədəf</div>
            <div className="text-xs text-violet-100">
              {todayCount >= DAILY_GOAL ? "Bu günkü hədəfə çatdın! 🎉" : `Bu gün ${DAILY_GOAL - todayCount} sessiya da tamamla`}
            </div>
            <div className="mt-2 flex items-center gap-2 text-xs font-bold">
              <span className="rounded-full bg-yellow-300 px-2 py-0.5 text-violet-900">Səviyyə {level}</span>
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/25">
                <div className="h-full rounded-full bg-yellow-300 transition-all" style={{ width: `${into}%` }} />
              </div>
              <span>{p.xp} XP</span>
            </div>
          </div>
        </div>
      </section>

      <div className="space-y-6 px-4 pt-5">
        <Link href="/quiz/qarisiq" className="anim-up block rounded-3xl bg-gradient-to-r from-amber-400 to-orange-500 p-5 text-white shadow-lg active:scale-[0.98]">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs font-bold uppercase tracking-wide text-amber-100">Sürətli başla</div>
              <div className="text-xl font-extrabold">Qarışıq viktorina 🎲</div>
              <div className="text-sm text-amber-50">Hər dəfə yeni suallar, bütün fənlərdən</div>
            </div>
            <div className="text-5xl anim-float">▶️</div>
          </div>
        </Link>

        <Card className={`bg-gradient-to-br ${fact.color} text-white !ring-0`}>
          <div className="flex items-start gap-3">
            <div className="text-4xl">{fact.emoji}</div>
            <div>
              <div className="text-[11px] font-bold uppercase tracking-wide text-white/80">Günün faktı • {fact.tag}</div>
              <div className="text-lg font-extrabold leading-tight">{fact.title}</div>
              <p className="mt-1 text-sm leading-snug text-white/95">{fact.text}</p>
            </div>
          </div>
          <Link href="/discover" className="mt-3 inline-block rounded-full bg-white/25 px-3 py-1 text-xs font-bold">Daha çox fakt →</Link>
        </Card>

        <section>
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-lg font-extrabold text-violet-900">Fənlər</h2>
            <Link href="/tests" className="text-xs font-bold text-violet-600">Hamısı →</Link>
          </div>
          <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 pb-1">
            {CATEGORIES.filter((c) => c.id !== "qarisiq").map((c) => {
              const left = remaining(p, c.id);
              return (
                <Link key={c.id} href={`/quiz/${c.id}`} className={`min-w-[120px] rounded-3xl bg-gradient-to-br ${c.gradient} p-4 text-white shadow-md active:scale-95`}>
                  <div className="text-3xl">{c.emoji}</div>
                  <div className="mt-2 text-sm font-extrabold">{c.name}</div>
                  <div className="text-[11px] text-white/80">{left === null ? "Limitsiz" : `Bu gün: ${usedToday(p, c.id)}/${p.limit}`}</div>
                </Link>
              );
            })}
          </div>
        </section>

        <section>
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-lg font-extrabold text-violet-900">Mini oyunlar</h2>
            <Link href="/games" className="text-xs font-bold text-violet-600">Hamısı →</Link>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {GAMES.map((g) => (
              <Link key={g.id} href={g.href} className={`rounded-3xl bg-gradient-to-br ${g.gradient} p-4 text-white shadow-md active:scale-95`}>
                <div className="text-3xl">{g.emoji}</div>
                <div className="mt-1 text-sm font-extrabold leading-tight">{g.name}</div>
                <div className="text-[11px] text-white/85">{g.desc}</div>
              </Link>
            ))}
          </div>
        </section>

        <Link href="/leaderboard" className="flex items-center justify-between rounded-3xl bg-white p-4 shadow-sm ring-1 ring-violet-100">
          <div className="flex items-center gap-3">
            <div className="text-3xl">🏅</div>
            <div>
              <div className="font-extrabold text-violet-900">Liderlər cədvəli</div>
              <div className="text-xs text-slate-500">Digər oyunçularla yarış</div>
            </div>
          </div>
          <span className="text-violet-500">→</span>
        </Link>
      </div>
    </div>
  );
}
