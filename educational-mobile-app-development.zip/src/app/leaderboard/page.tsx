"use client";

import { useEffect, useState } from "react";
import { useStore } from "@/lib/store";
import { PageHeader } from "@/components/ui";

type Row = { key: string; name: string; avatar: string; xp: number; mode: string };

export default function LeaderboardPage() {
  const { p } = useStore();
  const [rows, setRows] = useState<Row[] | null>(null);

  useEffect(() => {
    let alive = true;
    fetch("/api/leaderboard", { cache: "no-store" })
      .then((r) => r.json())
      .then((d: { rows: Row[] }) => alive && setRows(d.rows))
      .catch(() => alive && setRows([]));
    return () => {
      alive = false;
    };
  }, []);

  const me = p ? p.id.slice(-6) : "";
  const medal = ["🥇", "🥈", "🥉"];

  return (
    <div>
      <PageHeader title="Liderlər cədvəli" subtitle="XP-ə görə ən yaxşı 20 oyunçu" emoji="🏅" back="/" />
      <div className="space-y-2 p-4">
        {rows === null && <div className="py-10 text-center text-slate-400">Yüklənir…</div>}
        {rows && rows.length === 0 && (
          <div className="rounded-3xl bg-white p-6 text-center shadow-sm">
            <div className="text-5xl">🏁</div>
            <p className="mt-2 font-bold text-slate-600">Hələ heç kim xal qazanmayıb. İlk sən ol!</p>
          </div>
        )}
        {rows?.map((r, i) => (
          <div key={r.key + i} className={`flex items-center gap-3 rounded-2xl p-3 shadow-sm ring-1 ${r.key === me ? "bg-violet-600 text-white ring-violet-700" : "bg-white ring-violet-100"}`}>
            <div className="w-8 text-center text-xl font-extrabold">{medal[i] ?? i + 1}</div>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-100 text-2xl">{r.avatar}</div>
            <div className="flex-1">
              <div className="font-extrabold leading-tight">{r.name} {r.key === me && <span className="text-xs font-bold opacity-80">(sən)</span>}</div>
              <div className={`text-xs ${r.key === me ? "text-violet-100" : "text-slate-400"}`}>Səviyyə {Math.floor(r.xp / 100) + 1}</div>
            </div>
            <div className="font-extrabold">{r.xp} XP</div>
          </div>
        ))}
      </div>
    </div>
  );
}
