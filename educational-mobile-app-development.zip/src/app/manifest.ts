import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Zəka Dünyası",
    short_name: "Zəka",
    description: "Öyrən və əylən: testlər, oyunlar, faktlar, videolar",
    start_url: "/",
    display: "standalone",
    background_color: "#f4f1ff",
    theme_color: "#6d28d9",
    lang: "az",
    icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any" }],
  };
}
