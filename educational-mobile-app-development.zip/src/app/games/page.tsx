"use client";

import Link from "next/link";
import { GAMES } from "@/lib/categories";
import { remaining, useStore } from "@/lib/store";
import { PageHeader } from "@/components/ui";

export default function GamesPage() {
  const { ready, p } = useStore();
  return (
    <div>
      <PageHeader title="Mini oyunlar" subtitle="Oyna, öyrən, rekord qır" emoji="🎮" />
      <div className="space-y-3 p-4">
        {GAMES.map((g, i) => {
          const key = `game-${g.id}`;
          const left = ready && p ? remaining(p, key) : null;
          const best = ready && p ? p.best[key] : undefined;
          return (
            <Link
              key={g.id}
              href={g.href}
              style={{ animationDelay: `${i * 60}ms` }}
              className={`anim-up flex items-center gap-4 rounded-3xl bg-gradient-to-br ${g.gradient} p-4 text-white shadow-md active:scale-[0.98] ${left === 0 ? "opacity-60" : ""}`}
            >
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/25 text-4xl">{g.emoji}</div>
              <div className="flex-1">
                <div className="text-lg font-extrabold">{g.name}</div>
                <div className="text-xs text-white/90">{g.desc}</div>
                <div className="mt-1 flex gap-2 text-[11px] font-bold">
                  {best !== undefined && <span className="rounded-full bg-white/25 px-2 py-0.5">🏆 Rekord: {best}</span>}
                  <span className="rounded-full bg-white/25 px-2 py-0.5">
                    {left === null ? "Limitsiz" : left === 0 ? "🔒 Limit doldu" : `${left} cəhd qalıb`}
                  </span>
                </div>
              </div>
              <span className="text-2xl">›</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
