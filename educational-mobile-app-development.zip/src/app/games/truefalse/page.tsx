"use client";

import { useEffect, useState } from "react";
import { finishSession, markSeen, remaining, resetSeen } from "@/lib/store";
import { GameResult, GameShell, useGate } from "@/components/gameKit";
import { TF_BANK } from "@/lib/gamedata";
import { sample, shuffle } from "@/lib/quiz/util";

const KEY = "game-truefalse";
const COUNT = 10;

type Item = { idx: number; s: string; truth: boolean; e: string };

export default function TrueFalse() {
  const { state, p, recheck } = useGate(KEY);
  const [items, setItems] = useState<Item[]>([]);
  const [i, setI] = useState(0);
  const [picked, setPicked] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [result, setResult] = useState<{ stars: number; xp: number } | null>(null);

  useEffect(() => {
    if (state !== "ok" || !p) return;
    const seen = new Set(p.seen["tf"] ?? []);
    const all: Item[] = TF_BANK.map((t, idx) => ({ idx, s: t[0], truth: t[1], e: t[2] }));
    let T = all.filter((x) => x.truth && !seen.has(`tf${x.idx}`));
    let F = all.filter((x) => !x.truth && !seen.has(`tf${x.idx}`));
    if (T.length < COUNT / 2 || F.length < COUNT / 2) {
      resetSeen(["tf"]);
      T = all.filter((x) => x.truth);
      F = all.filter((x) => !x.truth);
    }
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setItems(shuffle([...sample(T, COUNT / 2), ...sample(F, COUNT / 2)]));
    setI(0);
    setPicked(null);
    setScore(0);
    setStreak(0);
    setResult(null);
  }, [state]); // eslint-disable-line react-hooks/exhaustive-deps

  const it = items[i];

  const answer = (v: boolean) => {
    if (picked !== null || !it) return;
    setPicked(v);
    markSeen("tf", [`tf${it.idx}`]);
    if (v === it.truth) {
      setScore((s) => s + 1);
      setStreak((s) => s + 1);
    } else setStreak(0);
    if (navigator.vibrate) navigator.vibrate(v === it.truth ? 20 : [40, 30, 40]);
  };

  const next = () => {
    if (i + 1 < items.length) {
      setI(i + 1);
      setPicked(null);
      return;
    }
    const stars = score >= 9 ? 3 : score >= 7 ? 2 : 1;
    const xp = score * 5 + 5;
    setResult({ stars, xp });
    finishSession({ section: KEY, kind: "game", correct: score, total: items.length, xp, bestKey: KEY, bestValue: score });
  };

  const ok = picked !== null && it && picked === it.truth;

  return (
    <GameShell title="Doğru, yoxsa yanlış?" emoji="✅" gate={state} gameName="Doğru, yoxsa yanlış?">
      {result ? (
        <GameResult
          title="Əla oyun!"
          big={`${score}/${items.length}`}
          lines={["düzgün cavab"]}
          xp={result.xp}
          stars={result.stars}
          limitLeft={p ? remaining(p, KEY) : null}
          onAgain={recheck}
        />
      ) : it ? (
        <div className="flex flex-1 flex-col">
          <div className="flex items-center gap-3">
            <div className="h-3 flex-1 overflow-hidden rounded-full bg-violet-200">
              <div className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all" style={{ width: `${((i + (picked !== null ? 1 : 0)) / items.length) * 100}%` }} />
            </div>
            <div className="text-sm font-extrabold text-violet-700">{i + 1}/{items.length}</div>
          </div>
          {streak >= 2 && <div className="mt-2 text-center text-sm font-extrabold text-orange-500 anim-pop">🔥 {streak} ardıcıl düzgün!</div>}

          <div key={i} className="anim-up mt-5 flex min-h-[170px] items-center justify-center rounded-3xl bg-white p-6 text-center shadow-lg ring-1 ring-violet-100">
            <p className="text-xl font-extrabold leading-snug text-slate-800">{it.s}</p>
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3">
            {[true, false].map((v) => {
              const chosen = picked === v;
              let cls = v ? "bg-emerald-500 text-white" : "bg-rose-500 text-white";
              if (picked !== null) {
                if (v === it.truth) cls = "bg-emerald-600 text-white ring-4 ring-emerald-200 anim-pop";
                else cls = chosen ? "bg-rose-600 text-white anim-shake" : "bg-slate-200 text-slate-400";
              }
              return (
                <button key={String(v)} onClick={() => answer(v)} disabled={picked !== null} className={`rounded-3xl py-6 text-xl font-extrabold shadow-lg transition active:scale-95 ${cls}`}>
                  {v ? "✅ Doğru" : "❌ Yanlış"}
                </button>
              );
            })}
          </div>

          {picked !== null && (
            <div className="anim-up mt-4 rounded-2xl bg-white p-4 shadow-sm ring-1 ring-violet-100">
              <div className={`font-extrabold ${ok ? "text-emerald-600" : "text-rose-600"}`}>{ok ? "🎉 Düzgün!" : `😅 Əslində bu ifadə ${it.truth ? "doğrudur" : "yanlışdır"}.`}</div>
              <p className="mt-1 text-sm text-slate-600">💡 {it.e}</p>
            </div>
          )}

          <div className="mt-auto pb-6 pt-4">
            <button onClick={next} disabled={picked === null} className={`w-full rounded-2xl py-4 text-lg font-extrabold text-white shadow-lg ${picked !== null ? "bg-gradient-to-r from-violet-600 to-pink-500 active:scale-95" : "bg-slate-300"}`}>
              {i + 1 < items.length ? "Növbəti →" : "Nəticəni gör 🏁"}
            </button>
          </div>
        </div>
      ) : null}
    </GameShell>
  );
}
