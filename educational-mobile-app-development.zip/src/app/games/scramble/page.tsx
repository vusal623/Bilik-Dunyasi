"use client";

import { useEffect, useRef, useState } from "react";
import { finishSession, markSeen, remaining, resetSeen } from "@/lib/store";
import { GameResult, GameShell, useGate } from "@/components/gameKit";
import { WORDS } from "@/lib/gamedata";
import { sample, shuffle } from "@/lib/quiz/util";

const KEY = "game-scramble";
const ROUNDS = 6;

type Tile = { id: number; ch: string };
type Round = { word: string; hint: string; idx: number };

function scrambleTiles(word: string): Tile[] {
  const chars = word.split("");
  let t = shuffle(chars);
  for (let i = 0; i < 10 && t.join("") === word; i++) t = shuffle(chars);
  return t.map((ch, id) => ({ id, ch }));
}

export default function Scramble() {
  const { state, p, recheck } = useGate(KEY);
  const [rounds, setRounds] = useState<Round[]>([]);
  const [i, setI] = useState(0);
  const [tiles, setTiles] = useState<Tile[]>([]);
  const [picked, setPicked] = useState<number[]>([]);
  const [status, setStatus] = useState<"idle" | "ok" | "bad">("idle");
  const [hintUsed, setHintUsed] = useState(false);
  const [points, setPoints] = useState(0);
  const [solved, setSolved] = useState(0);
  const [result, setResult] = useState<{ stars: number; xp: number } | null>(null);
  const locked = useRef(false);

  const loadRound = (r: Round) => {
    setTiles(scrambleTiles(r.word));
    setPicked([]);
    setStatus("idle");
    setHintUsed(false);
    locked.current = false;
  };

  useEffect(() => {
    if (state !== "ok" || !p) return;
    const level = p.mode === "kids" ? 1 : 2;
    const all = WORDS.map((w, idx) => ({ word: w[0], hint: w[1], lvl: w[2], idx })).filter((w) => w.lvl === level);
    const seen = new Set(p.seen["wd"] ?? []);
    let pool = all.filter((w) => !seen.has(`wd${w.idx}`));
    if (pool.length < ROUNDS) {
      resetSeen(["wd"]);
      pool = all;
    }
    const chosen = sample(pool, ROUNDS).map((w) => ({ word: w.word, hint: w.hint, idx: w.idx }));
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setRounds(chosen);
    setI(0);
    setPoints(0);
    setSolved(0);
    setResult(null);
    loadRound(chosen[0]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  const advance = (gained: number, ok: boolean) => {
    const r = rounds[i];
    markSeen("wd", [`wd${r.idx}`]);
    const newPoints = points + gained;
    const newSolved = solved + (ok ? 1 : 0);
    setPoints(newPoints);
    setSolved(newSolved);
    if (i + 1 < rounds.length) {
      setI(i + 1);
      loadRound(rounds[i + 1]);
    } else {
      const stars = newSolved >= 5 ? 3 : newSolved >= 3 ? 2 : 1;
      const xp = newPoints * 3 + 5;
      setResult({ stars, xp });
      finishSession({ section: KEY, kind: "game", correct: newSolved, total: rounds.length, xp, bestKey: KEY, bestValue: newPoints });
    }
  };

  const tap = (id: number) => {
    if (locked.current || picked.includes(id)) return;
    const next = [...picked, id];
    setPicked(next);
    const r = rounds[i];
    if (next.length === r.word.length) {
      locked.current = true;
      const built = next.map((x) => tiles.find((t) => t.id === x)?.ch).join("");
      if (built === r.word) {
        setStatus("ok");
        const gained = hintUsed ? 1 : 2;
        setTimeout(() => advance(gained, true), 900);
      } else {
        setStatus("bad");
        setTimeout(() => {
          setPicked([]);
          setStatus("idle");
          locked.current = false;
        }, 700);
      }
    }
  };

  const untap = (pos: number) => {
    if (locked.current) return;
    setPicked(picked.filter((_, k) => k !== pos));
  };

  const r = rounds[i];

  return (
    <GameShell title="Söz qarışığı" emoji="🔤" gate={state} gameName="Söz qarışığı">
      {result ? (
        <GameResult
          title="Oyun bitdi!"
          big={`${solved}/${rounds.length}`}
          lines={[`${points} xal qazandın`]}
          xp={result.xp}
          stars={result.stars}
          limitLeft={p ? remaining(p, KEY) : null}
          onAgain={recheck}
        />
      ) : r ? (
        <div>
          <div className="flex items-center gap-3">
            <div className="h-3 flex-1 overflow-hidden rounded-full bg-violet-200">
              <div className="h-full rounded-full bg-gradient-to-r from-teal-400 to-cyan-500 transition-all" style={{ width: `${(i / rounds.length) * 100}%` }} />
            </div>
            <div className="text-sm font-extrabold text-violet-700">{i + 1}/{rounds.length}</div>
          </div>

          <div className="mt-4 rounded-3xl bg-white p-5 text-center shadow-md ring-1 ring-violet-100">
            <div className="text-xs font-bold uppercase tracking-wide text-teal-600">İpucu</div>
            <p className="mt-1 text-lg font-extrabold text-slate-800">{r.hint}</p>
            <p className="mt-1 text-xs text-slate-400">{r.word.length} hərfli söz</p>
            {hintUsed && <p className="mt-2 text-sm font-bold text-amber-600">İlk hərf: {r.word[0].toLocaleUpperCase("az")}</p>}
          </div>

          <div className={`mt-5 flex min-h-[64px] flex-wrap justify-center gap-2 rounded-2xl p-3 ${status === "ok" ? "bg-emerald-100" : status === "bad" ? "bg-rose-100 anim-shake" : "bg-violet-100"}`}>
            {Array.from({ length: r.word.length }).map((_, pos) => {
              const t = picked[pos] !== undefined ? tiles.find((x) => x.id === picked[pos]) : undefined;
              return (
                <button
                  key={pos}
                  onClick={() => t && untap(pos)}
                  className={`flex h-12 w-10 items-center justify-center rounded-xl text-2xl font-extrabold uppercase shadow ${t ? "anim-pop bg-white text-violet-800" : "border-2 border-dashed border-violet-300 bg-transparent"}`}
                >
                  {t?.ch}
                </button>
              );
            })}
          </div>

          <div className="mt-5 flex flex-wrap justify-center gap-2">
            {tiles.map((t) => (
              <button
                key={t.id}
                onClick={() => tap(t.id)}
                disabled={picked.includes(t.id)}
                className={`flex h-14 w-12 items-center justify-center rounded-2xl text-2xl font-extrabold uppercase shadow-md transition active:scale-90 ${picked.includes(t.id) ? "bg-slate-200 text-transparent" : "bg-gradient-to-br from-teal-500 to-cyan-600 text-white"}`}
              >
                {t.ch}
              </button>
            ))}
          </div>

          <div className="mt-6 grid grid-cols-3 gap-2 text-sm font-bold">
            <button onClick={() => !locked.current && setPicked([])} className="rounded-2xl bg-white py-3 text-slate-600 shadow ring-1 ring-violet-100">↺ Təmizlə</button>
            <button onClick={() => setHintUsed(true)} disabled={hintUsed} className="rounded-2xl bg-amber-100 py-3 text-amber-700 shadow disabled:opacity-50">💡 İpucu</button>
            <button onClick={() => !locked.current && advance(0, false)} className="rounded-2xl bg-white py-3 text-slate-600 shadow ring-1 ring-violet-100">Keç ⏭</button>
          </div>
          {status === "ok" && <p className="mt-4 text-center text-lg font-extrabold text-emerald-600 anim-pop">🎉 Düzgün: {r.word}</p>}
        </div>
      ) : null}
    </GameShell>
  );
}
