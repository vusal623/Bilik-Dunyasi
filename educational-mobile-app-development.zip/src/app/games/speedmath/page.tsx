"use client";

import { useEffect, useRef, useState } from "react";
import { finishSession, remaining } from "@/lib/store";
import { GameResult, GameShell, useGate } from "@/components/gameKit";
import { genMath } from "@/lib/quiz/generators";
import { shuffle } from "@/lib/quiz/util";

const KEY = "game-speedmath";
const DURATION = 60_000;

type Q = { text: string; opts: string[]; answer: string };

function makeQ(score: number, kids: boolean): Q {
  const d = kids ? (score < 6 ? 1 : 2) : score < 6 ? 2 : 3;
  const q = genMath(d);
  return { text: q.q, opts: shuffle(q.o), answer: q.o[0] };
}

export default function SpeedMath() {
  const { state, p, recheck } = useGate(KEY);
  const kids = p?.mode === "kids";
  const [phase, setPhase] = useState<"ready" | "play" | "over">("ready");
  const [q, setQ] = useState<Q | null>(null);
  const [score, setScore] = useState(0);
  const [wrong, setWrong] = useState(0);
  const [left, setLeft] = useState(DURATION);
  const [flash, setFlash] = useState<"ok" | "bad" | null>(null);
  const endAt = useRef(0);
  const scoreRef = useRef(0);
  const wrongRef = useRef(0);
  const done = useRef(false);
  const [result, setResult] = useState<{ stars: number; xp: number } | null>(null);

  useEffect(() => {
    if (state === "ok") {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setPhase("ready");
      setResult(null);
    }
  }, [state]);

  const finish = () => {
    if (done.current) return;
    done.current = true;
    const s = scoreRef.current;
    const w = wrongRef.current;
    const stars = s >= 15 ? 3 : s >= 8 ? 2 : 1;
    const xp = Math.min(60, s * 3 + 5);
    setResult({ stars, xp });
    setPhase("over");
    finishSession({ section: KEY, kind: "game", correct: s, total: s + w, xp, bestKey: KEY, bestValue: s });
  };

  useEffect(() => {
    if (phase !== "play") return;
    const t = setInterval(() => {
      const rest = endAt.current - Date.now();
      if (rest <= 0) {
        setLeft(0);
        finish();
      } else setLeft(rest);
    }, 100);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  const begin = () => {
    scoreRef.current = 0;
    wrongRef.current = 0;
    done.current = false;
    setScore(0);
    setWrong(0);
    setLeft(DURATION);
    endAt.current = Date.now() + DURATION;
    setQ(makeQ(0, !!kids));
    setPhase("play");
  };

  const pick = (o: string) => {
    if (!q || phase !== "play") return;
    if (o === q.answer) {
      scoreRef.current += 1;
      setScore(scoreRef.current);
      setFlash("ok");
    } else {
      wrongRef.current += 1;
      setWrong(wrongRef.current);
      endAt.current -= 2000; // yanlış cavab: 2 saniyə cərimə
      setFlash("bad");
    }
    setTimeout(() => setFlash(null), 250);
    setQ(makeQ(scoreRef.current, !!kids));
  };

  return (
    <GameShell title="Sürətli hesab" emoji="⚡" gate={state} gameName="Sürətli hesab">
      {phase === "over" && result ? (
        <GameResult
          title="Vaxt bitdi!"
          big={`${score} düz`}
          lines={[`${wrong} səhv`, p?.best[KEY] !== undefined ? `Ən yaxşı nəticən: ${p.best[KEY]}` : ""].filter(Boolean)}
          xp={result.xp}
          stars={result.stars}
          limitLeft={p ? remaining(p, KEY) : null}
          onAgain={() => {
            setPhase("ready");
            recheck();
          }}
        />
      ) : phase === "ready" ? (
        <div className="anim-pop mt-6 rounded-3xl bg-white p-6 text-center shadow-lg ring-1 ring-violet-100">
          <div className="text-6xl anim-float">⚡</div>
          <h2 className="mt-3 text-2xl font-extrabold text-violet-900">60 saniyə!</h2>
          <p className="mt-2 text-sm text-slate-600">
            Misalları mümkün qədər sürətlə həll et. Hər düzgün cavab 1 xal verir. Səhv cavab 2 saniyə itirdir. Misallar getdikcə çətinləşir.
          </p>
          <button onClick={begin} className="mt-6 w-full rounded-2xl bg-gradient-to-r from-yellow-400 to-orange-500 py-4 text-xl font-extrabold text-white shadow-lg active:scale-95">
            Başla ▶
          </button>
        </div>
      ) : (
        <div className="flex flex-1 flex-col">
          <div className="flex items-center gap-3">
            <div className="h-4 flex-1 overflow-hidden rounded-full bg-violet-200">
              <div className={`h-full rounded-full transition-all duration-100 ${left < 10000 ? "bg-rose-500" : "bg-gradient-to-r from-yellow-400 to-orange-500"}`} style={{ width: `${(left / DURATION) * 100}%` }} />
            </div>
            <div className="w-10 text-right text-lg font-extrabold text-violet-800">{Math.ceil(left / 1000)}</div>
          </div>
          <div className="mt-3 text-center text-sm font-bold text-violet-700">Xal: {score}</div>

          <div className={`mt-4 rounded-3xl p-8 text-center text-4xl font-extrabold shadow-lg ring-1 transition ${flash === "ok" ? "bg-emerald-100 ring-emerald-300" : flash === "bad" ? "bg-rose-100 ring-rose-300 anim-shake" : "bg-white ring-violet-100"}`}>
            {q?.text}
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3">
            {q?.opts.map((o, i) => (
              <button key={`${q.text}-${i}`} onClick={() => pick(o)} className="rounded-2xl bg-white py-5 text-2xl font-extrabold text-violet-800 shadow-md ring-1 ring-violet-100 active:scale-95 active:bg-violet-100">
                {o}
              </button>
            ))}
          </div>
        </div>
      )}
    </GameShell>
  );
}
