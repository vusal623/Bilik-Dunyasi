"use client";

import { useEffect, useRef, useState } from "react";
import { finishSession, remaining } from "@/lib/store";
import { GameResult, GameShell, useGate } from "@/components/gameKit";
import { sample, shuffle } from "@/lib/quiz/util";

const KEY = "game-memory";
const EMOJIS = ["🐶", "🐱", "🦊", "🐼", "🦁", "🐸", "🐵", "🐧", "🐢", "🦋", "🐙", "🦄", "🍎", "🍌", "🍇", "🍓", "🚗", "🚀", "⚽", "🎈", "🌟", "🌈", "🎸", "🍕"];

type Card = { uid: number; emoji: string; open: boolean; done: boolean };

function deal(pairs: number): Card[] {
  const chosen = sample(EMOJIS, pairs);
  return shuffle([...chosen, ...chosen]).map((emoji, uid) => ({ uid, emoji, open: false, done: false }));
}

export default function MemoryGame() {
  const { state, p, recheck } = useGate(KEY);
  const pairs = p?.mode === "kids" ? 6 : 8;
  const [cards, setCards] = useState<Card[]>([]);
  const [moves, setMoves] = useState(0);
  const [secs, setSecs] = useState(0);
  const [over, setOver] = useState<{ stars: number; score: number; xp: number } | null>(null);
  const lock = useRef(false);
  const startRef = useRef(0);

  // Hər yeni oyunda kartlar təzədən qarışdırılır
  useEffect(() => {
    if (state === "ok") {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setCards(deal(pairs));
      setMoves(0);
      setSecs(0);
      setOver(null);
      lock.current = false;
      startRef.current = Date.now();
    }
  }, [state, pairs]);

  useEffect(() => {
    if (state !== "ok" || over) return;
    const t = setInterval(() => setSecs(Math.floor((Date.now() - startRef.current) / 1000)), 500);
    return () => clearInterval(t);
  }, [state, over]);

  const flip = (uid: number) => {
    if (lock.current || over) return;
    const c = cards.find((x) => x.uid === uid);
    if (!c || c.open || c.done) return;
    const next = cards.map((x) => (x.uid === uid ? { ...x, open: true } : x));
    setCards(next);
    const open = next.filter((x) => x.open && !x.done);
    if (open.length === 2) {
      setMoves((m) => m + 1);
      lock.current = true;
      if (open[0].emoji === open[1].emoji) {
        setTimeout(() => {
          const after = next.map((x) => (x.open ? { ...x, done: true, open: false } : x));
          setCards(after);
          lock.current = false;
          if (after.every((x) => x.done)) end(moves + 1);
        }, 400);
      } else {
        setTimeout(() => {
          setCards((cur) => cur.map((x) => (x.done ? x : { ...x, open: false })));
          lock.current = false;
        }, 800);
      }
    }
  };

  const end = (m: number) => {
    const score = Math.max(10, 100 - (m - pairs) * 6);
    const stars = m <= pairs * 1.5 ? 3 : m <= pairs * 2.3 ? 2 : 1;
    const xp = 10 + stars * 10;
    setOver({ stars, score, xp });
    finishSession({ section: KEY, kind: "game", correct: pairs, total: pairs, xp, bestKey: KEY, bestValue: score });
  };

  const cols = pairs === 6 ? "grid-cols-3" : "grid-cols-4";

  return (
    <GameShell title="Yaddaş kartları" emoji="🃏" gate={state} gameName="Yaddaş kartları">
      {over ? (
        <GameResult
          title="Bütün cütləri tapdın!"
          big={`${over.score} xal`}
          lines={[`${moves} gediş`, `${secs} saniyə`]}
          xp={over.xp}
          stars={over.stars}
          limitLeft={p ? remaining(p, KEY) : null}
          onAgain={recheck}
        />
      ) : (
        <>
          <div className="mb-3 flex justify-between text-sm font-bold">
            <span className="rounded-full bg-white px-3 py-1 text-violet-700 shadow-sm">👣 {moves} gediş</span>
            <span className="rounded-full bg-white px-3 py-1 text-violet-700 shadow-sm">⏱ {secs} san</span>
            <span className="rounded-full bg-white px-3 py-1 text-violet-700 shadow-sm">✅ {cards.filter((c) => c.done).length / 2}/{pairs}</span>
          </div>
          <div className={`grid ${cols} gap-3`}>
            {cards.map((c) => (
              <button
                key={c.uid}
                onClick={() => flip(c.uid)}
                className={`aspect-square rounded-2xl text-4xl shadow-md transition active:scale-95 ${
                  c.done ? "bg-emerald-100 opacity-70" : c.open ? "anim-flip bg-white ring-2 ring-violet-400" : "bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white"
                }`}
                aria-label="Kart"
              >
                {c.open || c.done ? c.emoji : "❓"}
              </button>
            ))}
          </div>
          <p className="mt-4 text-center text-xs text-slate-500">Eyni şəkilli kartları tap. Az gedişlə bitirsən, daha çox ulduz qazanırsan!</p>
        </>
      )}
    </GameShell>
  );
}
