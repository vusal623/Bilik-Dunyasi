import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import Shell from "@/components/Shell";

export const metadata: Metadata = {
  title: "Zəka Dünyası — öyrən və əylən",
  description: "Uşaqlar və böyüklər üçün məntiq testləri, fənn viktorinaları, maraqlı faktlar, videolar və mini oyunlar.",
  applicationName: "Zəka Dünyası",
  appleWebApp: { capable: true, title: "Zəka Dünyası", statusBarStyle: "default" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#6d28d9",
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="az">
      <body className="text-slate-900 antialiased">
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
