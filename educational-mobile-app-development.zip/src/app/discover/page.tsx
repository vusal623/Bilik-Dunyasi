"use client";

import { useEffect, useMemo, useState } from "react";
import { FACTS, PLANETS, VIDEOS } from "@/lib/content";
import { readFact, useStore } from "@/lib/store";
import { PageHeader } from "@/components/ui";

type Tab = "facts" | "videos" | "space";

function FactsTab() {
  const { p } = useStore();
  const tags = useMemo(() => ["Hamısı", ...Array.from(new Set(FACTS.map((f) => f.tag)))], []);
  const [tag, setTag] = useState("Hamısı");
  const list = useMemo(() => FACTS.filter((f) => tag === "Hamısı" || f.tag === tag), [tag]);
  const [i, setI] = useState(0);
  const f = list[i % list.length];

  useEffect(() => {
    readFact(f.id);
  }, [f.id]);

  const go = (d: number) => setI((x) => (x + d + list.length) % list.length);
  const random = () => setI(Math.floor(Math.random() * list.length));

  return (
    <div>
      <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-2">
        {tags.map((t) => (
          <button
            key={t}
            onClick={() => {
              setTag(t);
              setI(0);
            }}
            className={`shrink-0 rounded-full px-4 py-1.5 text-sm font-bold ${tag === t ? "bg-violet-600 text-white" : "bg-white text-violet-700 ring-1 ring-violet-200"}`}
          >
            {t}
          </button>
        ))}
      </div>

      <div key={f.id} className={`anim-pop mt-3 rounded-3xl bg-gradient-to-br ${f.color} p-6 text-white shadow-xl`}>
        <div className="flex items-center justify-between text-xs font-bold text-white/80">
          <span className="rounded-full bg-white/20 px-3 py-1">{f.tag}</span>
          <span>{(i % list.length) + 1} / {list.length}</span>
        </div>
        <div className="mt-4 text-7xl anim-float">{f.emoji}</div>
        <h2 className="mt-3 text-2xl font-extrabold leading-tight">{f.title}</h2>
        <p className="mt-2 text-base leading-relaxed text-white/95">{f.text}</p>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-3">
        <button onClick={() => go(-1)} className="rounded-2xl bg-white py-3 text-lg font-extrabold text-violet-700 shadow ring-1 ring-violet-100 active:scale-95">←</button>
        <button onClick={random} className="rounded-2xl bg-violet-600 py-3 text-lg font-extrabold text-white shadow active:scale-95">🎲</button>
        <button onClick={() => go(1)} className="rounded-2xl bg-white py-3 text-lg font-extrabold text-violet-700 shadow ring-1 ring-violet-100 active:scale-95">→</button>
      </div>
      <p className="mt-3 text-center text-xs text-slate-500">Oxunmuş faktlar: {p ? Math.min(p.facts.length, FACTS.length) : 0} / {FACTS.length}</p>
    </div>
  );
}

function VideosTab() {
  return (
    <div className="space-y-5">
      {VIDEOS.map((v) => (
        <div key={v.id} className="overflow-hidden rounded-3xl bg-white shadow-md ring-1 ring-violet-100">
          <video src={v.src} poster={v.poster} controls playsInline preload="none" className="aspect-video w-full bg-black object-cover" />
          <div className="p-4">
            <h3 className="text-lg font-extrabold text-violet-900">{v.emoji} {v.title}</h3>
            <p className="mt-1 text-sm leading-snug text-slate-600">{v.desc}</p>
            <p className="mt-2 text-[11px] text-slate-400">Video: {v.credit}</p>
          </div>
        </div>
      ))}
      <p className="text-center text-xs text-slate-400">Videolar üzərinə basaraq izlə. Mobil internetdə yükləmə vaxt ala bilər.</p>
    </div>
  );
}

function SpaceTab() {
  const [sel, setSel] = useState(PLANETS[2].id);
  const [paused, setPaused] = useState(false);
  const planet = PLANETS.find((x) => x.id === sel) ?? PLANETS[2];
  const order = PLANETS.findIndex((x) => x.id === sel) + 1;

  return (
    <div>
      <div className="overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 to-indigo-950 p-2 shadow-xl">
        <svg viewBox="0 0 520 520" className="w-full" role="img" aria-label="Günəş sistemi">
          {Array.from({ length: 40 }, (_, k) => (
            <circle key={k} cx={(k * 137) % 520} cy={(k * 211) % 520} r={(k % 3) * 0.5 + 0.6} fill="#fff" opacity={0.4 + (k % 4) * 0.15} />
          ))}
          <circle cx="260" cy="260" r="20" fill="#fbbf24" />
          <circle cx="260" cy="260" r="26" fill="#fbbf24" opacity="0.25" />
          {PLANETS.map((pl) => (
            <circle key={`o-${pl.id}`} cx="260" cy="260" r={pl.orbit} fill="none" stroke="#fff" strokeOpacity={sel === pl.id ? 0.55 : 0.15} strokeDasharray={sel === pl.id ? "0" : "3 5"} />
          ))}
          {PLANETS.map((pl, k) => (
            <g
              key={pl.id}
              style={{
                transformOrigin: "260px 260px",
                animation: `orbit ${pl.period}s linear infinite`,
                animationDelay: `-${(k * 7) % pl.period}s`,
                animationPlayState: paused ? "paused" : "running",
              }}
            >
              <circle cx={260 + pl.orbit} cy="260" r={pl.size + 10} fill="transparent" onClick={() => setSel(pl.id)} style={{ cursor: "pointer" }} />
              <circle cx={260 + pl.orbit} cy="260" r={pl.size} fill={pl.color} stroke={sel === pl.id ? "#fff" : "none"} strokeWidth="2" onClick={() => setSel(pl.id)} style={{ cursor: "pointer" }} />
              {pl.id === "saturn" && <circle cx={260 + pl.orbit} cy="260" r={pl.size + 5} fill="none" stroke={pl.color} strokeOpacity="0.6" />}
            </g>
          ))}
        </svg>
      </div>

      <div className="no-scrollbar -mx-4 mt-3 flex gap-2 overflow-x-auto px-4 pb-1">
        {PLANETS.map((pl) => (
          <button
            key={pl.id}
            onClick={() => setSel(pl.id)}
            className={`flex shrink-0 items-center gap-2 rounded-full px-3 py-1.5 text-sm font-bold ${sel === pl.id ? "bg-violet-600 text-white" : "bg-white text-slate-700 ring-1 ring-violet-200"}`}
          >
            <span className="inline-block h-3 w-3 rounded-full" style={{ background: pl.color }} />
            {pl.name}
          </button>
        ))}
      </div>

      <div key={planet.id} className="anim-pop mt-3 rounded-3xl bg-white p-5 shadow-md ring-1 ring-violet-100">
        <div className="flex items-center gap-3">
          <span className="inline-block h-10 w-10 rounded-full shadow-inner" style={{ background: planet.color }} />
          <div>
            <h3 className="text-xl font-extrabold text-violet-900">{planet.name}</h3>
            <div className="text-xs font-bold text-slate-400">Günəşdən {order}-ci planet</div>
          </div>
        </div>
        <p className="mt-3 text-sm leading-relaxed text-slate-700">{planet.fact}</p>
      </div>

      <button onClick={() => setPaused((x) => !x)} className="mt-3 w-full rounded-2xl bg-white py-3 text-sm font-bold text-violet-700 shadow ring-1 ring-violet-100">
        {paused ? "▶ Hərəkəti davam etdir" : "⏸ Hərəkəti dayandır"}
      </button>
      <p className="mt-3 text-center text-xs text-slate-400">Sürətlər və məsafələr əyani göstərmək üçün miqyassız verilib.</p>
    </div>
  );
}

export default function DiscoverPage() {
  const [tab, setTab] = useState<Tab>("facts");
  const tabs: { id: Tab; label: string; icon: string }[] = [
    { id: "facts", label: "Faktlar", icon: "💡" },
    { id: "videos", label: "Videolar", icon: "🎬" },
    { id: "space", label: "Kosmos", icon: "🪐" },
  ];
  return (
    <div>
      <PageHeader title="Kəşf et" subtitle="Maraqlı faktlar, videolar və kosmos" emoji="🔭" />
      <div className="px-4 pt-4">
        <div className="grid grid-cols-3 gap-1 rounded-2xl bg-violet-100 p-1">
          {tabs.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)} className={`rounded-xl py-2 text-sm font-extrabold transition ${tab === t.id ? "bg-white text-violet-700 shadow" : "text-violet-500"}`}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>
        <div className="mt-4">
          {tab === "facts" && <FactsTab />}
          {tab === "videos" && <VideosTab />}
          {tab === "space" && <SpaceTab />}
        </div>
      </div>
    </div>
  );
}
