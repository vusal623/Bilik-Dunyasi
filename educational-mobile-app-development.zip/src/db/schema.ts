import { integer, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";

export const players = pgTable("players", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: varchar("name", { length: 40 }).notNull(),
  avatar: varchar("avatar", { length: 16 }).notNull().default("🦊"),
  mode: varchar("mode", { length: 8 }).notNull().default("adult"),
  xp: integer("xp").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const results = pgTable("results", {
  id: serial("id").primaryKey(),
  playerId: varchar("player_id", { length: 64 }).notNull(),
  section: varchar("section", { length: 40 }).notNull(),
  kind: varchar("kind", { length: 8 }).notNull().default("quiz"),
  score: integer("score").notNull(),
  total: integer("total").notNull(),
  xp: integer("xp").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  questionId: varchar("question_id", { length: 80 }).notNull(),
  questionText: text("question_text").notNull(),
  note: text("note"),
  playerId: varchar("player_id", { length: 64 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
