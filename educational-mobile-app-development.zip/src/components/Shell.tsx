"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import { createProfile, useStore } from "@/lib/store";
import type { Mode } from "@/lib/categories";

const TABS = [
  { href: "/", label: "Ana səhifə", icon: "🏠" },
  { href: "/tests", label: "Testlər", icon: "📝" },
  { href: "/games", label: "Oyunlar", icon: "🎮" },
  { href: "/discover", label: "Kəşf et", icon: "🔭" },
  { href: "/profile", label: "Profil", icon: "👤" },
];

const AVATARS = ["🦊", "🐼", "🦁", "🐯", "🐸", "🦄", "🐙", "🦉", "🐧", "🐬", "🚀", "🧙"];

function Onboarding() {
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState(AVATARS[0]);
  const [mode, setMode] = useState<Mode>("adult");

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-violet-950/70 backdrop-blur-sm sm:items-center">
      <div className="anim-up w-full max-w-md rounded-t-3xl bg-white p-6 shadow-2xl sm:rounded-3xl">
        <div className="mb-1 text-center text-5xl anim-float">🧠</div>
        <h1 className="text-center text-2xl font-extrabold text-violet-900">Zəka Dünyasına xoş gəldin!</h1>
        <p className="mt-1 text-center text-sm text-slate-500">Öyrən, əylən və hər gün bir az daha ağıllı ol.</p>

        <label className="mt-5 block text-sm font-bold text-slate-700">Adın nədir?</label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={20}
          placeholder="Məsələn: Aysel"
          className="mt-1 w-full rounded-2xl border-2 border-violet-100 bg-violet-50 px-4 py-3 text-base font-semibold outline-none focus:border-violet-400"
        />

        <div className="mt-4 text-sm font-bold text-slate-700">Avatarını seç</div>
        <div className="mt-2 grid grid-cols-6 gap-2">
          {AVATARS.map((a) => (
            <button
              key={a}
              onClick={() => setAvatar(a)}
              className={`aspect-square rounded-2xl text-2xl transition ${avatar === a ? "scale-110 bg-violet-600 shadow-lg" : "bg-violet-50"}`}
              aria-label={`Avatar ${a}`}
            >
              {a}
            </button>
          ))}
        </div>

        <div className="mt-4 text-sm font-bold text-slate-700">Kimsən?</div>
        <div className="mt-2 grid grid-cols-2 gap-3">
          <button
            onClick={() => setMode("kids")}
            className={`rounded-2xl border-2 p-3 text-left transition ${mode === "kids" ? "border-pink-500 bg-pink-50" : "border-slate-200"}`}
          >
            <div className="text-2xl">🧒</div>
            <div className="font-extrabold">Uşaq</div>
            <div className="text-xs text-slate-500">Asan və orta suallar</div>
          </button>
          <button
            onClick={() => setMode("adult")}
            className={`rounded-2xl border-2 p-3 text-left transition ${mode === "adult" ? "border-violet-600 bg-violet-50" : "border-slate-200"}`}
          >
            <div className="text-2xl">🧑</div>
            <div className="font-extrabold">Böyük</div>
            <div className="text-xs text-slate-500">Orta və çətin suallar</div>
          </button>
        </div>

        <button
          onClick={() => createProfile(name, avatar, mode)}
          className="mt-6 w-full rounded-2xl bg-gradient-to-r from-violet-600 to-pink-500 py-4 text-lg font-extrabold text-white shadow-lg active:scale-95"
        >
          Başlayaq! 🚀
        </button>
      </div>
    </div>
  );
}

export default function Shell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { ready, p } = useStore();
  const hideNav = pathname.startsWith("/quiz") || pathname.startsWith("/games/");

  return (
    <div className="min-h-dvh bg-gradient-to-b from-violet-200 to-pink-100 sm:py-4">
      <div className="relative mx-auto min-h-dvh max-w-md bg-[#f4f1ff] sm:min-h-[calc(100dvh-2rem)] sm:overflow-hidden sm:rounded-[2rem] sm:shadow-2xl">
        <main className={hideNav ? "pb-6" : "pb-28"}>{children}</main>

        {!hideNav && (
          <nav className="safe-bottom fixed inset-x-0 bottom-0 z-40 mx-auto max-w-md border-t border-violet-100 bg-white/95 px-2 pt-2 backdrop-blur">
            <ul className="grid grid-cols-5">
              {TABS.map((t) => {
                const active = t.href === "/" ? pathname === "/" : pathname.startsWith(t.href);
                return (
                  <li key={t.href}>
                    <Link href={t.href} className="flex flex-col items-center gap-0.5 py-1">
                      <span className={`flex h-9 w-12 items-center justify-center rounded-2xl text-xl transition ${active ? "bg-violet-600 shadow-md shadow-violet-300" : ""}`}>
                        <span>{t.icon}</span>
                      </span>
                      <span className={`text-[10px] font-bold ${active ? "text-violet-700" : "text-slate-400"}`}>{t.label}</span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>
        )}

        {ready && (!p || !p.name) && <Onboarding />}
      </div>
    </div>
  );
}
