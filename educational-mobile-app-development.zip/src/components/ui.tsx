"use client";

import Link from "next/link";
import { useMemo, type ReactNode } from "react";

export function PageHeader({ title, subtitle, emoji, back }: { title: string; subtitle?: string; emoji?: string; back?: string }) {
  return (
    <header className="bg-gradient-to-br from-violet-600 to-fuchsia-600 px-5 pb-6 pt-8 text-white">
      {back && (
        <Link href={back} className="mb-2 inline-flex items-center gap-1 rounded-full bg-white/20 px-3 py-1 text-xs font-bold">
          ← Geri
        </Link>
      )}
      <div className="flex items-center gap-3">
        {emoji && <div className="text-4xl">{emoji}</div>}
        <div>
          <h1 className="text-2xl font-extrabold leading-tight">{title}</h1>
          {subtitle && <p className="text-sm text-violet-100">{subtitle}</p>}
        </div>
      </div>
    </header>
  );
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-3xl bg-white p-4 shadow-sm ring-1 ring-violet-100 ${className}`}>{children}</div>;
}

export function Ring({ value, size = 76, stroke = 9, color = "#7c3aed", children }: { value: number; size?: number; stroke?: number; color?: string; children?: ReactNode }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(1, value));
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#ede9fe" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - v)}
          style={{ transition: "stroke-dashoffset 0.8s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center text-center">{children}</div>
    </div>
  );
}

export function Confetti() {
  const pieces = useMemo(
    () =>
      Array.from({ length: 36 }, (_, i) => ({
        left: (i * 97) % 100,
        delay: ((i * 53) % 100) / 100,
        dur: 2 + ((i * 31) % 20) / 10,
        color: ["#f43f5e", "#f59e0b", "#10b981", "#3b82f6", "#a855f7", "#ec4899"][i % 6],
        size: 6 + (i % 4) * 3,
      })),
    [],
  );
  return (
    <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      {pieces.map((p, i) => (
        <span
          key={i}
          className="absolute top-0 block rounded-sm"
          style={{
            left: `${p.left}%`,
            width: p.size,
            height: p.size * 1.6,
            background: p.color,
            animation: `confetti ${p.dur}s ${p.delay}s linear forwards`,
          }}
        />
      ))}
    </div>
  );
}

export function LimitReached({ name, onBackHref = "/" }: { name: string; onBackHref?: string }) {
  return (
    <div className="anim-pop mx-5 mt-10 rounded-3xl bg-white p-6 text-center shadow-lg ring-1 ring-violet-100">
      <div className="text-6xl">😴</div>
      <h2 className="mt-3 text-xl font-extrabold text-violet-900">Bu gün üçün limit doldu</h2>
      <p className="mt-2 text-sm text-slate-600">
        “{name}” bölməsində bu gün çoxlu çalışdın — afərin! Yeni suallar sabah səni gözləyir. Bu arada başqa bölmələri sına.
      </p>
      <div className="mt-5 grid gap-2">
        <Link href="/tests" className="rounded-2xl bg-violet-600 py-3 font-bold text-white">Başqa test seç</Link>
        <Link href="/games" className="rounded-2xl bg-pink-500 py-3 font-bold text-white">Oyun oyna 🎮</Link>
        <Link href="/discover" className="rounded-2xl bg-sky-500 py-3 font-bold text-white">Faktlar və videolar 🔭</Link>
        <Link href={onBackHref} className="py-2 text-sm font-semibold text-slate-500">Ana səhifə</Link>
      </div>
      <p className="mt-3 text-xs text-slate-400">Limiti Profil bölməsindən dəyişə bilərsən.</p>
    </div>
  );
}
