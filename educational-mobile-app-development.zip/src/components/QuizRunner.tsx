"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { CATEGORY_MAP, QUIZ_SIZE, type PublicQuestion } from "@/lib/categories";
import { finishSession, markSeen, remaining, resetSeen, useStore } from "@/lib/store";
import { Confetti, LimitReached } from "@/components/ui";

type Phase = "init" | "loading" | "quiz" | "result" | "blocked" | "error";
type Answer = { q: PublicQuestion; picked: number };

const DIFF = ["", "Asan", "Orta", "Çətin"];
const DIFF_COLOR = ["", "bg-emerald-100 text-emerald-700", "bg-amber-100 text-amber-700", "bg-rose-100 text-rose-700"];

export default function QuizRunner({ cat }: { cat: string }) {
  const meta = CATEGORY_MAP[cat];
  const { ready, p } = useStore();
  const [phase, setPhase] = useState<Phase>("init");
  const [questions, setQuestions] = useState<PublicQuestion[]>([]);
  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [reported, setReported] = useState<string[]>([]);
  const [combo, setCombo] = useState(0);
  const [xpGain, setXpGain] = useState(0);
  const finished = useRef(false);
  const loadingRef = useRef(false);

  const start = useCallback(async () => {
    if (!p || loadingRef.current) return;
    if (remaining(p, cat) === 0) {
      setPhase("blocked");
      return;
    }
    loadingRef.current = true;
    setPhase("loading");
    try {
      const exclude = Object.values(p.seen).flat();
      const res = await fetch("/api/quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cat, mode: p.mode, exclude, count: QUIZ_SIZE }),
      });
      if (!res.ok) throw new Error("bad");
      const data = (await res.json()) as { questions: PublicQuestion[]; resetCats: string[] };
      if (!data.questions.length) throw new Error("empty");
      if (data.resetCats.length) resetSeen(data.resetCats);
      setQuestions(data.questions);
      setIdx(0);
      setPicked(null);
      setAnswers([]);
      setCombo(0);
      finished.current = false;
      setPhase("quiz");
    } catch {
      setPhase("error");
    } finally {
      loadingRef.current = false;
    }
  }, [p, cat]);

  useEffect(() => {
    if (ready && p && phase === "init") {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      void start();
    }
  }, [ready, p, phase, start]);

  if (!ready || !p || phase === "init" || phase === "loading") {
    return (
      <div className="flex min-h-[70dvh] flex-col items-center justify-center gap-3">
        <div className="anim-float text-6xl">{meta.emoji}</div>
        <div className="text-sm font-bold text-violet-700">Suallar hazırlanır…</div>
      </div>
    );
  }

  if (phase === "blocked") return <LimitReached name={meta.name} />;

  if (phase === "error") {
    return (
      <div className="mx-5 mt-16 rounded-3xl bg-white p-6 text-center shadow">
        <div className="text-5xl">😕</div>
        <p className="mt-2 font-bold">Suallar yüklənmədi.</p>
        <button
          onClick={() => {
            setPhase("init");
          }}
          className="mt-4 rounded-2xl bg-violet-600 px-6 py-3 font-bold text-white"
        >
          Yenidən cəhd et
        </button>
        <div><Link href="/tests" className="mt-3 inline-block text-sm text-slate-500">Geri</Link></div>
      </div>
    );
  }

  const total = questions.length;

  if (phase === "result") {
    const correct = answers.filter((a) => a.picked === a.q.answer).length;
    const pct = Math.round((correct / total) * 100);
    const stars = pct >= 90 ? 3 : pct >= 60 ? 2 : 1;
    const wrong = answers.filter((a) => a.picked !== a.q.answer);
    const left = remaining(p, cat);
    const msg = pct === 100 ? "Mükəmməl! 🏆" : pct >= 80 ? "Əla nəticə! 🎉" : pct >= 60 ? "Yaxşı! 👍" : "Yenə cəhd et, alınacaq! 💪";
    return (
      <div className="px-5 pt-8">
        {pct >= 80 && <Confetti />}
        <div className="anim-pop rounded-3xl bg-white p-6 text-center shadow-lg ring-1 ring-violet-100">
          <div className="text-5xl tracking-widest">
            {[1, 2, 3].map((s) => (
              <span key={s} className={s <= stars ? "" : "opacity-20 grayscale"}>⭐</span>
            ))}
          </div>
          <h2 className="mt-3 text-2xl font-extrabold text-violet-900">{msg}</h2>
          <div className="mt-1 text-slate-500">{meta.name} • {total} sualdan <b className="text-violet-700">{correct}</b> düzgün</div>
          <div className="mt-4 flex justify-center gap-3 text-sm font-bold">
            <span className="rounded-full bg-violet-100 px-3 py-1 text-violet-700">{pct}%</span>
            <span className="rounded-full bg-yellow-100 px-3 py-1 text-yellow-700">+{xpGain} XP</span>
            <span className="rounded-full bg-orange-100 px-3 py-1 text-orange-700">🔥 {p.streak} gün</span>
          </div>

          <div className="mt-6 grid gap-2">
            {left === 0 ? (
              <div className="rounded-2xl bg-slate-100 py-3 text-sm font-bold text-slate-500">🔒 Bu bölmə üçün bu günkü limit doldu</div>
            ) : (
              <button onClick={() => setPhase("init")} className="rounded-2xl bg-gradient-to-r from-violet-600 to-pink-500 py-3.5 font-extrabold text-white active:scale-95">
                Yeni suallarla davam et {left !== null && <span className="text-xs font-semibold opacity-80">({left} qalıb)</span>}
              </button>
            )}
            <Link href="/tests" className="rounded-2xl bg-violet-50 py-3 font-bold text-violet-700">Başqa test seç</Link>
            <Link href="/games" className="py-2 text-sm font-semibold text-slate-500">Mini oyunlara keç 🎮</Link>
          </div>
        </div>

        {wrong.length > 0 && (
          <div className="mt-6">
            <h3 className="mb-2 text-lg font-extrabold text-violet-900">Səhvlərini nəzərdən keçir 📖</h3>
            <div className="space-y-3">
              {wrong.map((a) => (
                <div key={a.q.id} className="rounded-2xl bg-white p-4 text-sm shadow-sm ring-1 ring-rose-100">
                  <div className="font-bold text-slate-800">{a.q.q}</div>
                  <div className="mt-2 text-rose-600">✗ Sənin cavabın: {a.q.options[a.picked]}</div>
                  <div className="text-emerald-700">✓ Düzgün cavab: <b>{a.q.options[a.q.answer]}</b></div>
                  <div className="mt-1 text-slate-500">{a.q.explain}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  const q = questions[idx];
  const answered = picked !== null;
  const isCorrect = answered && picked === q.answer;

  const choose = (i: number) => {
    if (answered) return;
    setPicked(i);
    setAnswers((a) => [...a, { q, picked: i }]);
    markSeen(q.cat, [q.id]);
    setCombo((c) => (i === q.answer ? c + 1 : 0));
    if (navigator.vibrate) navigator.vibrate(i === q.answer ? 20 : [40, 30, 40]);
  };

  const next = () => {
    if (idx + 1 < total) {
      setIdx(idx + 1);
      setPicked(null);
      return;
    }
    if (!finished.current) {
      finished.current = true;
      const correct = answers.filter((a) => a.picked === a.q.answer).length;
      const gain = correct * 10 + (correct === total ? 20 : 0) + 5;
      setXpGain(gain);
      finishSession({ section: cat, kind: "quiz", correct, total, xp: gain });
    }
    setPhase("result");
  };

  const report = async () => {
    setReported((r) => [...r, q.id]);
    fetch("/api/report", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ questionId: q.id, questionText: `${q.q} | düzgün: ${q.options[q.answer]}`, playerId: p.id }),
    }).catch(() => {});
  };

  return (
    <div className="flex min-h-dvh flex-col px-4 pt-5">
      <div className="flex items-center gap-3">
        <Link href="/tests" className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-lg shadow ring-1 ring-violet-100" aria-label="Çıx">✕</Link>
        <div className="h-3 flex-1 overflow-hidden rounded-full bg-violet-200">
          <div className="h-full rounded-full bg-gradient-to-r from-violet-500 to-pink-500 transition-all duration-500" style={{ width: `${((idx + (answered ? 1 : 0)) / total) * 100}%` }} />
        </div>
        <div className="text-sm font-extrabold text-violet-700">{idx + 1}/{total}</div>
      </div>

      <div className="mt-3 flex items-center justify-between text-xs font-bold">
        <span className={`rounded-full bg-gradient-to-r ${meta.gradient} px-3 py-1 text-white`}>{CATEGORY_MAP[q.cat]?.emoji} {CATEGORY_MAP[q.cat]?.name}</span>
        <span className="flex items-center gap-2">
          {combo >= 2 && <span className="anim-pop rounded-full bg-orange-100 px-2 py-1 text-orange-600">🔥 {combo} ardıcıl</span>}
          <span className={`rounded-full px-2 py-1 ${DIFF_COLOR[q.d]}`}>{DIFF[q.d]}</span>
        </span>
      </div>

      <div key={q.id} className="anim-up mt-4 rounded-3xl bg-white p-5 shadow-md ring-1 ring-violet-100">
        <p className="text-lg font-extrabold leading-snug text-slate-800">{q.q}</p>
      </div>

      <div key={`o-${q.id}`} className="mt-4 grid gap-3">
        {q.options.map((o, i) => {
          const isAns = i === q.answer;
          const isPicked = picked === i;
          let cls = "bg-white text-slate-800 ring-1 ring-violet-100 active:scale-[0.98]";
          if (answered) {
            if (isAns) cls = "bg-emerald-500 text-white ring-2 ring-emerald-600 anim-pop";
            else if (isPicked) cls = "bg-rose-500 text-white ring-2 ring-rose-600 anim-shake";
            else cls = "bg-white/60 text-slate-400 ring-1 ring-slate-100";
          }
          return (
            <button
              key={i}
              disabled={answered}
              onClick={() => choose(i)}
              style={{ animationDelay: answered ? undefined : `${i * 50}ms` }}
              className={`flex items-center gap-3 rounded-2xl px-4 py-3.5 text-left text-base font-bold shadow-sm transition ${cls}`}
            >
              <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm font-extrabold ${answered && (isAns || isPicked) ? "bg-white/30" : "bg-violet-100 text-violet-700"}`}>
                {answered && isAns ? "✓" : answered && isPicked ? "✗" : String.fromCharCode(65 + i)}
              </span>
              <span className="flex-1">{o}</span>
            </button>
          );
        })}
      </div>

      {answered && (
        <div className="anim-up mt-4 rounded-2xl bg-white p-4 shadow-sm ring-1 ring-violet-100">
          <div className={`text-sm font-extrabold ${isCorrect ? "text-emerald-600" : "text-rose-600"}`}>
            {isCorrect ? "🎉 Düzgün!" : "😅 Düzgün cavab: " + q.options[q.answer]}
          </div>
          <p className="mt-1 text-sm leading-snug text-slate-600">💡 {q.explain}</p>
          <div className="mt-2 text-right">
            {reported.includes(q.id) ? (
              <span className="text-xs font-semibold text-slate-400">Təşəkkürlər, yoxlayacağıq ✔</span>
            ) : (
              <button onClick={report} className="text-xs font-semibold text-slate-400 underline">🚩 Sualda səhv var?</button>
            )}
          </div>
        </div>
      )}

      <div className="mt-auto pb-6 pt-4">
        <button
          onClick={next}
          disabled={!answered}
          className={`w-full rounded-2xl py-4 text-lg font-extrabold text-white shadow-lg transition ${answered ? "bg-gradient-to-r from-violet-600 to-pink-500 active:scale-95" : "bg-slate-300"}`}
        >
          {idx + 1 < total ? "Növbəti →" : "Nəticəni gör 🏁"}
        </button>
      </div>
    </div>
  );
}
