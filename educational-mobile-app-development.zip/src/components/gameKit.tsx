"use client";

import Link from "next/link";
import { useCallback, useEffect, useState, type ReactNode } from "react";
import { remaining, useStore, type Profile } from "@/lib/store";
import { Confetti, LimitReached } from "@/components/ui";

/** Oyuna girişi gündəlik limitə görə yoxlayır. */
export function useGate(key: string) {
  const { ready, p } = useStore();
  const [state, setState] = useState<"wait" | "ok" | "blocked">("wait");

  useEffect(() => {
    if (ready && p && state === "wait") {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setState(remaining(p, key) === 0 ? "blocked" : "ok");
    }
  }, [ready, p, state, key]);

  const recheck = useCallback(() => setState("wait"), []);
  return { state, p: p as Profile | null, recheck };
}

export function GameShell({
  title,
  emoji,
  gate,
  gameName,
  children,
}: {
  title: string;
  emoji: string;
  gate: "wait" | "ok" | "blocked";
  gameName: string;
  children: ReactNode;
}) {
  if (gate === "wait") {
    return <div className="flex min-h-[70dvh] items-center justify-center text-6xl anim-float">{emoji}</div>;
  }
  if (gate === "blocked") return <LimitReached name={gameName} />;
  return (
    <div className="flex min-h-dvh flex-col px-4 pt-5">
      <div className="mb-3 flex items-center gap-3">
        <Link href="/games" className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-lg shadow ring-1 ring-violet-100" aria-label="Çıx">✕</Link>
        <h1 className="text-xl font-extrabold text-violet-900">{emoji} {title}</h1>
      </div>
      {children}
    </div>
  );
}

export function GameResult({
  title,
  big,
  lines,
  xp,
  stars,
  onAgain,
  limitLeft,
}: {
  title: string;
  big: string;
  lines: string[];
  xp: number;
  stars: number;
  onAgain: () => void;
  limitLeft: number | null;
}) {
  return (
    <div className="pt-6">
      {stars >= 2 && <Confetti />}
      <div className="anim-pop rounded-3xl bg-white p-6 text-center shadow-lg ring-1 ring-violet-100">
        <div className="text-5xl tracking-widest">
          {[1, 2, 3].map((s) => (
            <span key={s} className={s <= stars ? "" : "opacity-20 grayscale"}>⭐</span>
          ))}
        </div>
        <h2 className="mt-3 text-2xl font-extrabold text-violet-900">{title}</h2>
        <div className="mt-1 text-5xl font-extrabold text-fuchsia-600">{big}</div>
        <div className="mt-2 space-y-0.5 text-sm text-slate-500">
          {lines.map((l) => (
            <div key={l}>{l}</div>
          ))}
        </div>
        <div className="mt-3 inline-block rounded-full bg-yellow-100 px-3 py-1 text-sm font-bold text-yellow-700">+{xp} XP</div>
        <div className="mt-6 grid gap-2">
          {limitLeft === 0 ? (
            <div className="rounded-2xl bg-slate-100 py-3 text-sm font-bold text-slate-500">🔒 Bu oyun üçün bu günkü limit doldu</div>
          ) : (
            <button onClick={onAgain} className="rounded-2xl bg-gradient-to-r from-violet-600 to-pink-500 py-3.5 font-extrabold text-white active:scale-95">
              Yenidən oyna 🔄
            </button>
          )}
          <Link href="/games" className="rounded-2xl bg-violet-50 py-3 font-bold text-violet-700">Başqa oyun</Link>
          <Link href="/tests" className="py-2 text-sm font-semibold text-slate-500">Testlərə keç 📝</Link>
        </div>
      </div>
    </div>
  );
}
