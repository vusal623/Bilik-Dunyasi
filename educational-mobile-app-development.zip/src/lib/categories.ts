export type CategoryId =
  | "riyaziyyat"
  | "mentiq"
  | "cografiya"
  | "tarix"
  | "elm"
  | "tebiet"
  | "dil"
  | "qarisiq";

export type Category = {
  id: CategoryId;
  name: string;
  emoji: string;
  desc: string;
  gradient: string; // tailwind gradient classes
};

export const CATEGORIES: Category[] = [
  { id: "qarisiq", name: "Qarışıq", emoji: "🎲", desc: "Bütün fənlərdən sürpriz suallar", gradient: "from-fuchsia-500 to-purple-600" },
  { id: "mentiq", name: "Məntiq", emoji: "🧩", desc: "Düşün, tap, həll et", gradient: "from-violet-500 to-indigo-600" },
  { id: "riyaziyyat", name: "Riyaziyyat", emoji: "➗", desc: "Rəqəmlərlə əyləncə", gradient: "from-sky-500 to-blue-600" },
  { id: "cografiya", name: "Coğrafiya", emoji: "🌍", desc: "Ölkələr, dənizlər, dağlar", gradient: "from-emerald-500 to-teal-600" },
  { id: "tarix", name: "Tarix", emoji: "🏛️", desc: "Keçmişin sirləri", gradient: "from-amber-500 to-orange-600" },
  { id: "elm", name: "Elm", emoji: "🔬", desc: "Fizika, kimya, kosmos, bədən", gradient: "from-cyan-500 to-sky-600" },
  { id: "tebiet", name: "Təbiət", emoji: "🦁", desc: "Heyvanlar və bitkilər aləmi", gradient: "from-lime-500 to-green-600" },
  { id: "dil", name: "Dil", emoji: "📚", desc: "Azərbaycan və ingilis dili, ədəbiyyat", gradient: "from-rose-500 to-pink-600" },
];

export const CATEGORY_MAP: Record<string, Category> = Object.fromEntries(
  CATEGORIES.map((c) => [c.id, c]),
);

export type GameInfo = {
  id: string;
  name: string;
  emoji: string;
  desc: string;
  href: string;
  gradient: string;
};

export const GAMES: GameInfo[] = [
  { id: "memory", name: "Yaddaş kartları", emoji: "🃏", desc: "Eyni cütləri tap", href: "/games/memory", gradient: "from-pink-500 to-rose-600" },
  { id: "speedmath", name: "Sürətli hesab", emoji: "⚡", desc: "60 saniyədə nə qədər həll edirsən?", href: "/games/speedmath", gradient: "from-yellow-400 to-orange-500" },
  { id: "scramble", name: "Söz qarışığı", emoji: "🔤", desc: "Qarışmış hərflərdən sözü tap", href: "/games/scramble", gradient: "from-teal-500 to-cyan-600" },
  { id: "truefalse", name: "Doğru, yoxsa yanlış?", emoji: "✅", desc: "Sürətli qərar ver", href: "/games/truefalse", gradient: "from-indigo-500 to-violet-600" },
];

export const QUIZ_SIZE = 8;

export type Mode = "kids" | "adult";

/** Public question shape sent to the client */
export type PublicQuestion = {
  id: string;
  cat: string;
  d: number;
  q: string;
  options: string[];
  answer: number; // index in options
  explain: string;
};
