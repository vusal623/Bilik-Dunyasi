export type Fact = { id: string; emoji: string; tag: string; title: string; text: string; color: string };

export const FACTS: Fact[] = [
  { id: "f01", emoji: "🍯", tag: "Təbiət", title: "Xarab olmayan bal", text: "Düzgün saxlandıqda bal minillərlə xarab olmur. Arxeoloqlar qədim məzarlarda çox köhnə bal küpələri tapıblar. Balın tərkibində az su və çox şəkər var, bakteriyalar orada çoxala bilmir.", color: "from-amber-400 to-orange-500" },
  { id: "f02", emoji: "🐙", tag: "Təbiət", title: "Üç ürəkli ahtapot", text: "Ahtapotun 3 ürəyi var: ikisi qanı qəlsəmələrə, üçüncüsü isə bütün bədənə vurur. Qanının rəngi isə mavidir.", color: "from-fuchsia-500 to-purple-600" },
  { id: "f03", emoji: "🪐", tag: "Kosmos", title: "Veneradakı gün ildən uzundur", text: "Venera öz oxu ətrafında çox yavaş fırlanır: bir fırlanma təxminən 243 Yer günü çəkir. Günəş ətrafında dövrəsi isə təxminən 225 Yer günüdür. Yəni orada bir gün bir ildən uzundur!", color: "from-indigo-500 to-violet-600" },
  { id: "f04", emoji: "🦒", tag: "Təbiət", title: "Zürafənin boynu", text: "Zürafənin boynu 2 metrə yaxın uzunluqda olsa da, orada cəmi 7 boyun fəqərəsi var — insanla eyni say. Sadəcə hər fəqərə çox uzundur.", color: "from-yellow-400 to-amber-600" },
  { id: "f05", emoji: "🗼", tag: "Elm", title: "Eyfel qülləsi yayda ucalır", text: "Metal istidən genişlənir. Buna görə Eyfel qülləsi isti yay günlərində təxminən 15 sm-ə qədər hündürləşə bilər.", color: "from-slate-500 to-slate-700" },
  { id: "f06", emoji: "💧", tag: "Bədən", title: "Bədənimiz su ilə doludur", text: "Yetkin insan bədəninin təxminən 50–60%-i sudur. Beyin və ürək toxumasında isə su payı daha da yüksəkdir.", color: "from-sky-400 to-blue-600" },
  { id: "f07", emoji: "☀️", tag: "Kosmos", title: "Günəş işığının səyahəti", text: "Günəşdən çıxan işıq Yerə təxminən 8 dəqiqə 20 saniyəyə çatır. Yəni biz Günəşi həmişə 8 dəqiqə əvvəlki halında görürük.", color: "from-yellow-400 to-orange-500" },
  { id: "f08", emoji: "🗿", tag: "Azərbaycan", title: "Qobustanın qayaüstü rəsmləri", text: "Qobustanda 6000-dən çox qayaüstü təsvir tapılıb. Bu rəsmlərdə ovçular, heyvanlar və qayıqlar təsvir olunub. Ərazi UNESCO Dünya İrsi siyahısındadır.", color: "from-stone-500 to-amber-700" },
  { id: "f09", emoji: "🔥", tag: "Azərbaycan", title: "Odlar yurdu", text: "Azərbaycan “Odlar yurdu” adlanır. Abşeron yarımadasındakı Yanar Dağda təbii qaz yer səthindən çıxıb yanır və alov sönmür.", color: "from-red-500 to-orange-500" },
  { id: "f10", emoji: "🌊", tag: "Azərbaycan", title: "Xəzər — dünyanın ən böyük gölü", text: "Xəzər dənizinin sahəsi təxminən 371 000 kvadrat kilometrdir. Okeanla əlaqəsi olmadığı üçün onu dünyanın ən böyük gölü hesab edirlər.", color: "from-cyan-500 to-blue-600" },
  { id: "f11", emoji: "🌕", tag: "Kosmos", title: "Ay uzaqlaşır", text: "Ay hər il Yerdən təxminən 3,8 sm uzaqlaşır. Bu, dırnaqlarımızın uzanma sürətinə yaxındır.", color: "from-slate-400 to-indigo-600" },
  { id: "f12", emoji: "♟️", tag: "Mədəniyyət", title: "Şahmatın yaranması", text: "Şahmatın təxminən 1500 il əvvəl Hindistanda yaranan “çaturanqa” oyunundan əmələ gəldiyi hesab olunur. Bu gün dünyada milyonlarla insan şahmat oynayır.", color: "from-zinc-600 to-zinc-800" },
  { id: "f13", emoji: "⛰️", tag: "Coğrafiya", title: "Everestin hündürlüyü", text: "Everest dağının hündürlüyü təxminən 8849 metrdir. Bu, dəniz səviyyəsindən ölçülən ən hündür nöqtədir.", color: "from-teal-500 to-emerald-600" },
  { id: "f14", emoji: "❤️", tag: "Bədən", title: "Ürək yorulmur", text: "Ürəyimiz gündə təxminən 100 000 dəfə döyünür və hər dəfə qanı bədənə vurur.", color: "from-rose-500 to-red-600" },
  { id: "f15", emoji: "🪐", tag: "Kosmos", title: "Saturn suda üzərdi", text: "Saturnun orta sıxlığı suyun sıxlığından azdır. Yetərincə böyük hovuz olsaydı, Saturn suda üzərdi. Onun gözəl halqaları isə əsasən buz və qaya parçalarından ibarətdir.", color: "from-amber-300 to-yellow-600" },
  { id: "f16", emoji: "🔴", tag: "Kosmos", title: "Mars niyə qırmızıdır?", text: "Marsın torpağında çoxlu dəmir oksidi (pas) var. Məhz buna görə planet qırmızımtıl görünür.", color: "from-red-500 to-orange-600" },
  { id: "f17", emoji: "🔊", tag: "Elm", title: "Səs suda daha sürətlidir", text: "Səs suda havadakından təxminən 4 dəfə sürətli yayılır. Bərk cisimlərdə isə daha da sürətli.", color: "from-blue-500 to-cyan-600" },
  { id: "f18", emoji: "👂", tag: "Bədən", title: "Ən kiçik sümük", text: "İnsan bədənində ən kiçik sümük qulağın içindəki “üzəngi” sümüyüdür. Uzunluğu cəmi 3 millimetrə yaxındır.", color: "from-pink-400 to-rose-500" },
  { id: "f19", emoji: "🐬", tag: "Təbiət", title: "Yarı oyaq yatan delfin", text: "Delfinlər yatarkən beyinlərinin yalnız yarısı yatır, digər yarısı oyaq qalır. Bu, onlara nəfəs almaq üçün səthə çıxmağa imkan verir.", color: "from-sky-500 to-indigo-600" },
  { id: "f20", emoji: "🍌", tag: "Təbiət", title: "Banan giləmeyvədir!", text: "Botanika baxımından banan giləmeyvədir, çiyələk isə yox. Elm bəzən gündəlik təsəvvürlərimizdən fərqli olur.", color: "from-yellow-300 to-amber-500" },
  { id: "f21", emoji: "🌍", tag: "Coğrafiya", title: "Mavi planet", text: "Yer səthinin təxminən 71%-i su ilə örtülüdür. Buna görə kosmosdan Yer mavi görünür.", color: "from-blue-500 to-emerald-500" },
  { id: "f22", emoji: "🌈", tag: "Elm", title: "Göy qurşağı", text: "Göy qurşağı yağış damcılarında ağ işığın rənglərə ayrılması nəticəsində yaranır. Adətən 7 rəng sayılır: qırmızı, narıncı, sarı, yaşıl, mavi, göy və bənövşəyi.", color: "from-red-400 via-yellow-400 to-blue-500" },
  { id: "f23", emoji: "🎻", tag: "Azərbaycan", title: "Tar — milli musiqi alətimiz", text: "“Tar ifaçılığı sənəti” UNESCO-nun Qeyri-maddi mədəni irs siyahısına daxil edilib. Tar Azərbaycan musiqisinin ən əsas alətlərindəndir.", color: "from-orange-500 to-rose-600" },
  { id: "f24", emoji: "🌷", tag: "Azərbaycan", title: "Novruz bayramı", text: "Novruz yaz bayramıdır və Günəşin yaz bərabərliyi vaxtı, mart ayının 20-si ətrafında qeyd olunur. Bu bayram UNESCO-nun Qeyri-maddi mədəni irs siyahısındadır.", color: "from-lime-500 to-green-600" },
  { id: "f25", emoji: "🧠", tag: "Bədən", title: "Beyin neyronları", text: "İnsan beynində təxminən 86 milyard neyron (sinir hüceyrəsi) var. Onlar bir-birinə elektrik siqnalları göndərərək düşünməyimizi təmin edir.", color: "from-purple-500 to-fuchsia-600" },
  { id: "f26", emoji: "🦴", tag: "Bədən", title: "Körpənin sümükləri", text: "Yenidoğulmuş körpənin 300-ə yaxın sümüyü olur. Böyüdükcə onların bəziləri birləşir və yetkin insanda 206 sümük qalır.", color: "from-stone-400 to-stone-600" },
  { id: "f27", emoji: "🐘", tag: "Təbiət", title: "Ağıllı fillər", text: "Fillər güzgüdə özlərini tanıya bilən az sayda heyvandandır. Bu, onların çox ağıllı olduğunu göstərir.", color: "from-gray-500 to-slate-600" },
];

export type VideoItem = {
  id: string;
  title: string;
  desc: string;
  src: string;
  poster: string;
  emoji: string;
  credit: string;
};

export const VIDEOS: VideoItem[] = [
  {
    id: "v1",
    title: "Okean dalğaları",
    emoji: "🌊",
    desc: "Dalğaların əksəriyyətini külək yaradır. Külək suyun səthi ilə sürtünərək enerjisini ona ötürür və dalğalar əmələ gəlir.",
    src: "https://videos.pexels.com/video-files/34693119/14704850_1920_1080_30fps.mp4",
    poster: "https://images.pexels.com/videos/34693119/nature-ocean-sea-slow-motion-34693119.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    credit: "Jay VN / Pexels",
  },
  {
    id: "v2",
    title: "Arı çiçəkdə",
    emoji: "🐝",
    desc: "Arılar nektar toplayarkən çiçək tozcuqlarını bir çiçəkdən digərinə daşıyır. Bu prosesə tozlanma deyilir və meyvə-tərəvəzin çoxu buna möhtacdır.",
    src: "https://videos.pexels.com/video-files/33379446/14211095_3840_2160_60fps.mp4",
    poster: "https://images.pexels.com/videos/33379446/4k-8k-bee-bees-33379446.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    credit: "Hao Le / Pexels",
  },
  {
    id: "v3",
    title: "Süd Yolu",
    emoji: "🌌",
    desc: "Günəş sistemimiz Süd Yolu qalaktikasındadır. Bu qalaktikada yüz milyardlarla ulduz var. Gecə qaranlıq yerdən baxanda onu səmada parlaq zolaq kimi görmək olar.",
    src: "https://videos.pexels.com/video-files/12336972/12336972-hd_1920_1028_60fps.mp4",
    poster: "https://images.pexels.com/videos/12336972/pexels-photo-12336972.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    credit: "Borys Zaitsev / Pexels",
  },
  {
    id: "v4",
    title: "Şəlalə",
    emoji: "💦",
    desc: "Şəlalə çay suyunun yüksək yerdən aşağı düşdüyü yerdir. Dünyanın ən hündür şəlaləsi Venesuelanın Anxel şəlaləsidir (təxminən 979 m).",
    src: "https://videos.pexels.com/video-files/4208225/4208225-hd_1920_1080_24fps.mp4",
    poster: "https://images.pexels.com/videos/4208225/pexels-photo-4208225.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    credit: "K / Pexels",
  },
];

export type Planet = {
  id: string;
  name: string;
  color: string;
  size: number; // px radius in the svg
  orbit: number; // px radius
  period: number; // seconds for animation
  fact: string;
};

export const PLANETS: Planet[] = [
  { id: "merkuri", name: "Merkuri", color: "#a8a29e", size: 4, orbit: 44, period: 6, fact: "Günəşə ən yaxın və ən kiçik planetdir. Onun bir ili cəmi 88 Yer günü çəkir." },
  { id: "venera", name: "Venera", color: "#fbbf24", size: 6, orbit: 66, period: 10, fact: "Günəş sisteminin ən isti planetidir (səthində təxminən 465°C). Orada bir gün bir ildən uzundur." },
  { id: "yer", name: "Yer", color: "#38bdf8", size: 6.5, orbit: 90, period: 14, fact: "Həyatın məlum olduğu yeganə planetdir. Səthinin təxminən 71%-i su ilə örtülüdür." },
  { id: "mars", name: "Mars", color: "#ef4444", size: 5, orbit: 114, period: 19, fact: "“Qırmızı planet”dir. Burada Günəş sisteminin ən hündür vulkanı — Olimp dağı (təxminən 22 km) yerləşir." },
  { id: "yupiter", name: "Yupiter", color: "#f59e0b", size: 14, orbit: 148, period: 28, fact: "Ən böyük planetdir. “Böyük Qırmızı Ləkə” adlanan nəhəng fırtına əsrlərdir davam edir." },
  { id: "saturn", name: "Saturn", color: "#fcd34d", size: 11, orbit: 184, period: 38, fact: "Halqaları ilə məşhurdur. Halqalar əsasən buz və qaya parçalarından ibarətdir." },
  { id: "uran", name: "Uran", color: "#67e8f9", size: 8, orbit: 214, period: 48, fact: "Demək olar ki, “yan üstə yatmış” halda fırlanır — oxu təxminən 98° əyilib." },
  { id: "neptun", name: "Neptun", color: "#3b82f6", size: 8, orbit: 242, period: 58, fact: "Günəşdən ən uzaq planetdir. Orada Günəş sisteminin ən güclü küləkləri əsir." },
];

export function factOfTheDay(): Fact {
  const d = new Date();
  const n = Math.floor(new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() / 86400000);
  return FACTS[n % FACTS.length];
}
