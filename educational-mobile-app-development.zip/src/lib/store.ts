"use client";

import { useSyncExternalStore } from "react";
import type { Mode } from "./categories";

const KEY = "zeka-dunyasi:v1";

export type DayStat = { c: number; t: number };

export type Profile = {
  id: string;
  name: string;
  avatar: string;
  mode: Mode;
  xp: number;
  streak: number;
  bestStreak: number;
  lastDay: string; // YYYY-MM-DD
  /** Hər bölmə üçün gündəlik sessiya limiti (0 = limitsiz) */
  limit: number;
  /** Kateqoriya üzrə görülmüş sabit sualların id-ləri */
  seen: Record<string, string[]>;
  daily: { date: string; sessions: Record<string, number> };
  stats: Record<string, { c: number; t: number }>;
  days: Record<string, DayStat>;
  best: Record<string, number>;
  sessions: number;
  facts: string[];
  perfect: number;
};

export type Snapshot = { ready: boolean; p: Profile | null };

const SERVER_SNAPSHOT: Snapshot = { ready: false, p: null };
let snapshot: Snapshot = SERVER_SNAPSHOT;
let loaded = false;
const listeners = new Set<() => void>();

export function dayKey(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function yesterdayKey(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return dayKey(d);
}

function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}

function defaults(): Profile {
  return {
    id: uid(),
    name: "",
    avatar: "🦊",
    mode: "adult",
    xp: 0,
    streak: 0,
    bestStreak: 0,
    lastDay: "",
    limit: 5,
    seen: {},
    daily: { date: dayKey(), sessions: {} },
    stats: {},
    days: {},
    best: {},
    sessions: 0,
    facts: [],
    perfect: 0,
  };
}

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  let p: Profile | null = null;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<Profile>;
      p = { ...defaults(), ...parsed };
    }
  } catch {
    p = null;
  }
  if (p && p.daily.date !== dayKey()) p = { ...p, daily: { date: dayKey(), sessions: {} } };
  snapshot = { ready: true, p };
}

function commit(p: Profile | null) {
  snapshot = { ready: true, p };
  try {
    if (p) window.localStorage.setItem(KEY, JSON.stringify(p));
    else window.localStorage.removeItem(KEY);
  } catch {
    // storage may be unavailable (private mode)
  }
  listeners.forEach((l) => l());
}

function subscribe(cb: () => void) {
  load();
  listeners.add(cb);
  // initial client snapshot became available
  queueMicrotask(cb);
  return () => {
    listeners.delete(cb);
  };
}

function getSnapshot(): Snapshot {
  load();
  return snapshot;
}

export function useStore(): Snapshot {
  return useSyncExternalStore(subscribe, getSnapshot, () => SERVER_SNAPSHOT);
}

/* ───────────── actions ───────────── */

function current(): Profile | null {
  load();
  return snapshot.p;
}

function fresh(p: Profile): Profile {
  return p.daily.date === dayKey() ? p : { ...p, daily: { date: dayKey(), sessions: {} } };
}

function syncPlayer(p: Profile) {
  fetch("/api/players", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id: p.id, name: p.name, avatar: p.avatar, mode: p.mode, xp: p.xp }),
  }).catch(() => {});
}

export function createProfile(name: string, avatar: string, mode: Mode) {
  const p = { ...(current() ?? defaults()), name: name.trim() || "Oyunçu", avatar, mode };
  commit(p);
  syncPlayer(p);
}

export function updateProfile(patch: Partial<Pick<Profile, "name" | "avatar" | "mode" | "limit">>) {
  const p = current();
  if (!p) return;
  const next = { ...p, ...patch };
  commit(next);
  if (patch.name !== undefined || patch.avatar !== undefined || patch.mode !== undefined) syncPlayer(next);
}

export function resetAll() {
  commit(null);
}

export function markSeen(cat: string, ids: string[]) {
  const p = current();
  if (!p) return;
  const staticIds = ids.filter((i) => !i.startsWith("g:"));
  if (!staticIds.length) return;
  const set = new Set([...(p.seen[cat] ?? []), ...staticIds]);
  commit({ ...p, seen: { ...p.seen, [cat]: Array.from(set) } });
}

export function resetSeen(cats: string[]) {
  const p = current();
  if (!p || !cats.length) return;
  const seen = { ...p.seen };
  for (const c of cats) delete seen[c];
  commit({ ...p, seen });
}

export function readFact(id: string) {
  const p = current();
  if (!p || p.facts.includes(id)) return;
  commit({ ...p, facts: [...p.facts, id].slice(-200) });
}

export function usedToday(p: Profile, key: string): number {
  if (p.daily.date !== dayKey()) return 0;
  return p.daily.sessions[key] ?? 0;
}

export function remaining(p: Profile, key: string): number | null {
  if (!p.limit) return null;
  return Math.max(0, p.limit - usedToday(p, key));
}

export function xpForLevel(xp: number) {
  const level = Math.floor(xp / 100) + 1;
  return { level, into: xp % 100, next: 100 };
}

/** Sessiya bitəndə çağırılır: limit, seriya, XP, statistika və serverə göndərmə. */
export function finishSession(args: {
  section: string;
  kind: "quiz" | "game";
  correct: number;
  total: number;
  xp: number;
  bestKey?: string;
  bestValue?: number;
}) {
  const base = current();
  if (!base) return;
  const p = fresh(base);
  const today = dayKey();
  const ystd = yesterdayKey();
  let streak = p.streak;
  if (p.lastDay !== today) streak = p.lastDay === ystd ? p.streak + 1 : 1;

  const days = { ...p.days };
  const d = days[today] ?? { c: 0, t: 0 };
  days[today] = { c: d.c + args.correct, t: d.t + args.total };
  // yalnız son 30 gün saxlanılır
  const keys = Object.keys(days).sort();
  while (keys.length > 30) delete days[keys.shift() as string];

  const stats = { ...p.stats };
  if (args.kind === "quiz") {
    const s = stats[args.section] ?? { c: 0, t: 0 };
    stats[args.section] = { c: s.c + args.correct, t: s.t + args.total };
  }

  const best = { ...p.best };
  if (args.bestKey && args.bestValue !== undefined && args.bestValue > (best[args.bestKey] ?? 0)) {
    best[args.bestKey] = args.bestValue;
  }

  const next: Profile = {
    ...p,
    xp: p.xp + args.xp,
    streak,
    bestStreak: Math.max(p.bestStreak, streak),
    lastDay: today,
    daily: { date: today, sessions: { ...p.daily.sessions, [args.section]: (p.daily.sessions[args.section] ?? 0) + 1 } },
    days,
    stats,
    best,
    sessions: p.sessions + 1,
    perfect: p.perfect + (args.kind === "quiz" && args.total > 0 && args.correct === args.total ? 1 : 0),
  };
  commit(next);

  fetch("/api/results", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ playerId: p.id, section: args.section, kind: args.kind, score: args.correct, total: args.total, xp: args.xp }),
  }).catch(() => {});
}

export type Badge = { id: string; emoji: string; name: string; desc: string; earned: boolean };

export function computeBadges(p: Profile): Badge[] {
  const totalCorrect = Object.values(p.stats).reduce((a, s) => a + s.c, 0);
  const cats = Object.entries(p.stats).filter(([, s]) => s.t >= 8 && s.c / s.t >= 0.8).length;
  return [
    { id: "first", emoji: "🌱", name: "İlk addım", desc: "İlk sessiyanı tamamla", earned: p.sessions >= 1 },
    { id: "ten", emoji: "🎯", name: "Hədəfdə", desc: "10 düzgün cavab ver", earned: totalCorrect >= 10 },
    { id: "hundred", emoji: "💯", name: "Yüzlük", desc: "100 düzgün cavab ver", earned: totalCorrect >= 100 },
    { id: "perfect", emoji: "🏆", name: "Mükəmməl", desc: "Testi 100% düzgün tamamla", earned: p.perfect >= 1 },
    { id: "streak3", emoji: "🔥", name: "3 gün seriya", desc: "3 gün ardıcıl oyna", earned: p.bestStreak >= 3 },
    { id: "streak7", emoji: "🌟", name: "Həftə qəhrəmanı", desc: "7 gün ardıcıl oyna", earned: p.bestStreak >= 7 },
    { id: "master", emoji: "🎓", name: "Fənn ustası", desc: "Bir fənn üzrə 80%+ nəticə (8+ sual)", earned: cats >= 1 },
    { id: "curious", emoji: "🔍", name: "Maraqlı", desc: "10 maraqlı fakt oxu", earned: p.facts.length >= 10 },
  ];
}
