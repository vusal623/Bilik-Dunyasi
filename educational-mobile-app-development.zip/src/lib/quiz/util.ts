export const ri = (a: number, b: number) => Math.floor(Math.random() * (b - a + 1)) + a;

export function pick<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function shuffle<T>(arr: readonly T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function sample<T>(arr: readonly T[], n: number): T[] {
  return shuffle(arr).slice(0, n);
}

/** Correct number first, then 3 unique plausible wrong numbers. */
export function numOptions(correct: number, extra: number[] = [], spread = 10): string[] {
  const cands = [correct + 1, correct - 1, correct + 2, correct - 2, correct + 10, correct - 10, correct + spread, correct - spread, correct + 5, correct - 5, ...extra];
  const unique = Array.from(new Set(cands.filter((n) => n !== correct && n >= 0 && Number.isFinite(n))));
  // extra (typical mistakes) first, then the rest shuffled
  const extraSet = new Set(extra.filter((n) => n !== correct && n >= 0));
  const prio = unique.filter((n) => extraSet.has(n));
  const rest = shuffle(unique.filter((n) => !extraSet.has(n)));
  const wrong = [...shuffle(prio).slice(0, 2), ...rest].slice(0, 3);
  let k = 3;
  while (wrong.length < 3) {
    const n = correct + k++;
    if (!wrong.includes(n) && n !== correct) wrong.push(n);
  }
  return [String(correct), ...wrong.map(String)];
}
