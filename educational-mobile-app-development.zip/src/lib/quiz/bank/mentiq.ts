import type { StaticQ } from "../types";

export const MENTIQ: StaticQ[] = [
  ["m01", 1, "Hansı söz artıqdır: alma, armud, nar, stol?", ["stol", "alma", "armud", "nar"], "Alma, armud və nar meyvədir, stol isə mebel."],
  ["m02", 1, "Ardıcıllığı davam et: 🔴 🔵 🔴 🔵 🔴 ?", ["🔵", "🔴", "🟢", "🟡"], "Rənglər növbə ilə təkrarlanır: qırmızı, mavi, qırmızı, mavi… Növbəti mavidir."],
  ["m03", 1, "Dünən cümə idisə, sabah hansı gündür?", ["Bazar", "Şənbə", "Cümə axşamı", "Bazar ertəsi"], "Dünən cümə idisə, bu gün şənbədir; sabah isə bazardır."],
  ["m04", 1, "Hansı daha ağırdır: 1 kq pambıq, yoxsa 1 kq dəmir?", ["Eyni ağırlıqdadırlar", "1 kq pambıq", "1 kq dəmir", "Müəyyən etmək olmaz"], "Hər ikisi 1 kq-dır. Pambıq sadəcə daha çox yer tutur."],
  ["m05", 1, "Hansı ədəd digərlərindən fərqlidir: 2, 4, 6, 7, 8?", ["7", "2", "4", "8"], "7 təkdir, qalanlarının hamısı cütdür."],
  ["m06", 1, "Hər insanın 2 əli var. Üç nəfərin birlikdə neçə əli var?", ["6", "3", "5", "8"], "3 × 2 = 6."],
  ["m07", 1, "Çərşənbə axşamından sonra hansı gün gəlir?", ["Çərşənbə", "Cümə axşamı", "Bazar ertəsi", "Cümə"], "Həftənin ardıcıllığı: bazar ertəsi, çərşənbə axşamı, çərşənbə, cümə axşamı…"],
  ["m08", 2, "Nə qədər çox götürsən, o qədər böyüyür. Bu nədir?", ["Çuxur", "Torba", "Dağ", "Sandıq"], "Çuxurdan nə qədər torpaq çıxarsan, o qədər böyüyər."],
  ["m09", 2, "Qutuda 5 qırmızı və 3 mavi top var. Gözün bağlı olduqda ən azı neçə top çəksən, mütləq eyni rəngdə iki top olacaq?", ["3", "2", "4", "5"], "2 top fərqli rəngdə ola bilər (1 qırmızı + 1 mavi). 3-cü top mütləq onlardan biri ilə eyni rəngdə olacaq."],
  ["m10", 2, "Fermerin 17 qoyunu var. 9-u istisna olmaqla hamısı satıldı. Neçə qoyun qaldı?", ["9", "8", "17", "0"], "“9-dan başqa hamısı satıldı” deməli, 9 qoyun satılmayıb."],
  ["m11", 2, "Cərgədə duran uşaqlardan Aysel soldan 5-ci, sağdan 4-cüdür. Cərgədə cəmi neçə uşaq var?", ["8", "9", "10", "7"], "5 + 4 − 1 = 8 (Ayseli iki dəfə saymışıq)."],
  ["m12", 2, "Saat tam 3:00-ı göstərəndə saat və dəqiqə əqrəbləri arasındakı bucaq neçə dərəcədir?", ["90°", "60°", "120°", "180°"], "Saat dövrəsi 360°-dir, hər saat 30°. 3 saat = 90°."],
  ["m13", 2, "Ardıcıllığı davam et: 1, 1, 2, 3, 5, 8, ?", ["13", "11", "12", "16"], "Fibonaççi ardıcıllığıdır: hər ədəd əvvəlki iki ədədin cəmidir (5 + 8 = 13)."],
  ["m14", 3, "5 nəfər toplaşıb və hər kəs digər hər kəslə düz bir dəfə əl sıxıb. Cəmi neçə əl sıxma olub?", ["10", "20", "15", "25"], "Cütlərin sayı: 5 × 4 ÷ 2 = 10."],
  ["m15", 3, "Divar saatı 3 dəfə vuranda ilk vuruşdan sonuncuya qədər 2 saniyə keçir. 6 dəfə vuranda ilk vuruşdan sonuncuya qədər neçə saniyə keçər?", ["5", "4", "6", "12"], "3 vuruşda 2 fasilə var (hər biri 1 san.). 6 vuruşda 5 fasilə olur, yəni 5 saniyə."],
  ["m16", 3, "Ata 40, oğul 10 yaşındadır. Neçə ildən sonra ata oğuldan düz 3 dəfə böyük olacaq?", ["5", "10", "15", "20"], "40 + x = 3 × (10 + x) → 40 + x = 30 + 3x → x = 5. Yoxlama: 45 = 3 × 15."],
  ["m17", 3, "Sinifdə 30 şagird var. 18-i futbolu, 15-i basketbolu sevir, hər kəs ən azı birini sevir. Neçə şagird hər ikisini sevir?", ["3", "7", "12", "33"], "18 + 15 = 33 və 33 − 30 = 3 nəfər iki dəfə sayılıb."],
  ["m18", 3, "Ailədə 4 qız var və hər qızın düz bir qardaşı var. Ailədə cəmi neçə uşaq var?", ["5", "8", "4", "6"], "Bütün qızların qardaşı eyni oğlandır: 4 qız + 1 oğlan = 5."],
  ["m19", 3, "5 maşın 5 dəqiqəyə 5 detal hazırlayır. 100 maşın 100 detalı neçə dəqiqəyə hazırlayar?", ["5", "100", "20", "1"], "Hər maşın 5 dəqiqəyə 1 detal hazırlayır. 100 maşın da 5 dəqiqəyə 100 detal hazırlayar."],
  ["m20", 3, "Gölməçədə nilufər hər gün öz sahəsini 2 dəfə artırır. 48-ci gün gölməçəni tam örtür. Gölməçənin yarısını neçənci gün örtmüşdü?", ["47", "24", "46", "40"], "Sahə hər gün 2 dəfə artdığı üçün tam örtüyün yarısı bir gün əvvəl, yəni 47-ci gün olub."],
];
