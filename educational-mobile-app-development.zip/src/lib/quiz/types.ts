/**
 * Static question format (compact tuple):
 *  [id, difficulty(1-3), question, [CORRECT, wrong1, wrong2, wrong3], explanation]
 * The FIRST option is always the correct one. Options are shuffled by the engine
 * on every delivery, so the correct answer position is random each time.
 */
export type StaticQ = readonly [
  id: string,
  d: 1 | 2 | 3,
  q: string,
  o: readonly [string, string, string, string],
  e: string,
];

export type Question = {
  id: string;
  cat: string;
  d: number;
  q: string;
  /** correct first, unshuffled */
  o: string[];
  e: string;
  generated: boolean;
};
