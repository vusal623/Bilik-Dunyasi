import type { Question } from "./types";
import { numOptions, pick, ri, sample, shuffle } from "./util";

let counter = 0;
const gid = (p: string) => `g:${p}:${++counter}`;

function mk(cat: string, d: number, p: string, q: string, o: string[], e: string): Question {
  return { id: gid(p), cat, d, q, o, e, generated: true };
}

/* ───────────────────────── RİYAZİYYAT ───────────────────────── */

export function genMath(d: number): Question {
  const cat = "riyaziyyat";
  if (d <= 1) {
    const t = ri(0, 3);
    if (t === 0) {
      const a = ri(2, 12), b = ri(2, 12);
      return mk(cat, 1, "add1", `${a} + ${b} = ?`, numOptions(a + b, [], 4), `${a} + ${b} = ${a + b}`);
    }
    if (t === 1) {
      const a = ri(8, 30), b = ri(2, a - 1);
      return mk(cat, 1, "sub1", `${a} − ${b} = ?`, numOptions(a - b, [], 4), `${a} − ${b} = ${a - b}`);
    }
    if (t === 2) {
      const a = ri(2, 5), b = ri(2, 9);
      return mk(cat, 1, "mul1", `${a} × ${b} = ?`, numOptions(a * b, [a + b], 4), `${a} × ${b} = ${a * b}`);
    }
    const objs = ["alma", "konfet", "şar", "kitab", "top", "düymə"];
    const o = pick(objs);
    const a = ri(10, 20), b = ri(2, 6), c = ri(2, 6);
    return mk(cat, 1, "word1", `Qutuda ${a} ${o} var. ${b} ${o} götürüldü, sonra ${c} ${o} əlavə edildi. İndi qutuda neçə ${o} var?`, numOptions(a - b + c, [a + b + c, a - b - c], 4), `${a} − ${b} + ${c} = ${a - b + c}`);
  }
  if (d === 2) {
    const t = ri(0, 5);
    if (t === 0) {
      const a = ri(23, 79), b = ri(14, 48);
      return mk(cat, 2, "add2", `${a} + ${b} = ?`, numOptions(a + b, [a + b + 10, a + b - 10], 10), `${a} + ${b} = ${a + b}`);
    }
    if (t === 1) {
      const a = ri(52, 98), b = ri(13, 47);
      return mk(cat, 2, "sub2", `${a} − ${b} = ?`, numOptions(a - b, [a - b + 10, a - b - 10], 10), `${a} − ${b} = ${a - b}`);
    }
    if (t === 2) {
      const a = ri(6, 12), b = ri(6, 12);
      return mk(cat, 2, "mul2", `${a} × ${b} = ?`, numOptions(a * b, [a * b + a, a * b - b], 10), `${a} × ${b} = ${a * b}`);
    }
    if (t === 3) {
      const b = ri(3, 12), q = ri(3, 12);
      return mk(cat, 2, "div2", `${b * q} ÷ ${b} = ?`, numOptions(q, [q + 1, q - 1], 3), `${q} × ${b} = ${b * q}, deməli ${b * q} ÷ ${b} = ${q}`);
    }
    if (t === 4) {
      const a = ri(4, 15), b = ri(3, 12);
      return mk(cat, 2, "perim", `Uzunluğu ${a} sm, eni ${b} sm olan düzbucaqlının perimetri neçə santimetrdir?`, numOptions(2 * (a + b), [a * b, a + b], 6), `Perimetr = 2 × (${a} + ${b}) = ${2 * (a + b)}`);
    }
    const a = ri(4, 15), b = ri(3, 12);
    return mk(cat, 2, "area", `Uzunluğu ${a} sm, eni ${b} sm olan düzbucaqlının sahəsi neçə kvadrat santimetrdir?`, numOptions(a * b, [2 * (a + b), a + b], 6), `Sahə = ${a} × ${b} = ${a * b}`);
  }
  // d3
  const t = ri(0, 5);
  if (t === 0) {
    const p = pick([10, 20, 25, 50, 75]);
    const base = pick([40, 80, 120, 160, 200, 240, 360, 400, 480, 600]);
    const ans = (base * p) / 100;
    return mk(cat, 3, "pct", `${base} ədədinin ${p}%-i neçədir?`, numOptions(ans, [base - ans, ans * 2], 10), `${base} × ${p} ÷ 100 = ${ans}`);
  }
  if (t === 1) {
    const n = ri(11, 25);
    return mk(cat, 3, "sq", `${n}² (${n}-nin kvadratı) neçəyə bərabərdir?`, numOptions(n * n, [n * 2, n * n + n, n * n - n], 10), `${n} × ${n} = ${n * n}`);
  }
  if (t === 2) {
    const a = ri(3, 20), b = ri(2, 9), c = ri(2, 9);
    return mk(cat, 3, "order", `${a} + ${b} × ${c} = ?`, numOptions(a + b * c, [(a + b) * c], 6), `Əvvəlcə vurma: ${b} × ${c} = ${b * c}, sonra toplama: ${a} + ${b * c} = ${a + b * c}`);
  }
  if (t === 3) {
    const k = ri(2, 6), x = ri(2, 15), a = ri(1, 9);
    const b = k * x + a;
    return mk(cat, 3, "eq", `${k}x + ${a} = ${b} tənliyində x neçəyə bərabərdir?`, numOptions(x, [x + 1, x - 1, b - a], 3), `${k}x = ${b} − ${a} = ${b - a}, x = ${b - a} ÷ ${k} = ${x}`);
  }
  if (t === 4) {
    const h = ri(3, 14), b = ri(2, 10) * 2;
    const area = (b * h) / 2;
    return mk(cat, 3, "tri", `Əsası ${b} sm, hündürlüyü ${h} sm olan üçbucağın sahəsi neçə kvadrat santimetrdir?`, numOptions(area, [b * h, b + h], 8), `Sahə = ${b} × ${h} ÷ 2 = ${area}`);
  }
  const a = ri(2, 9), b = ri(2, 9), c = ri(2, 9), e = ri(1, 9);
  const val = (a + b) * c - e;
  return mk(cat, 3, "expr", `(${a} + ${b}) × ${c} − ${e} = ?`, numOptions(val, [a + b * c - e, (a + b) * (c - e)], 8), `(${a} + ${b}) = ${a + b}; ${a + b} × ${c} = ${(a + b) * c}; ${(a + b) * c} − ${e} = ${val}`);
}

/* ───────────────────────── MƏNTİQ ───────────────────────── */

const NAMES: [string, string][] = [
  ["Əli", "Əlidən"], ["Leyla", "Leyladan"], ["Aysel", "Ayseldən"], ["Rəşad", "Rəşaddan"], ["Kamran", "Kamrandan"],
  ["Nigar", "Nigardan"], ["Tural", "Turaldan"], ["Nərmin", "Nərmindən"], ["Samir", "Samirdən"], ["Aynur", "Aynurdan"],
];

export function genLogic(d: number): Question {
  const cat = "mentiq";
  const kinds = d <= 1 ? ["arith1", "odd", "time1", "order1"] : d === 2 ? ["arith2", "geo", "alt", "mid", "odd", "order2", "age"] : ["fib", "tri", "sqp", "alt", "geo3", "oddk", "time3", "order2", "age"];
  const kind = pick(kinds);

  const seqQ = (terms: number[], next: number, rule: string): Question =>
    mk(cat, d, "seq", `Ardıcıllığı davam et: ${terms.join(", ")}, ?`, numOptions(next, [next + 1, next - 1], 6), rule);

  switch (kind) {
    case "arith1": {
      const s = ri(1, 15), st = ri(2, 5);
      const t = [0, 1, 2, 3, 4].map((i) => s + i * st);
      return seqQ(t, s + 5 * st, `Hər dəfə ${st} artır: ${t[4]} + ${st} = ${s + 5 * st}`);
    }
    case "arith2": {
      const s = ri(3, 30), st = ri(4, 12);
      const t = [0, 1, 2, 3, 4].map((i) => s + i * st);
      return seqQ(t, s + 5 * st, `Hər dəfə ${st} artır: ${t[4]} + ${st} = ${s + 5 * st}`);
    }
    case "geo": {
      const s = ri(1, 4), r = pick([2, 3]);
      const t = [0, 1, 2, 3].map((i) => s * r ** i);
      return seqQ(t, s * r ** 4, `Hər ədəd əvvəlkinin ${r} mislidir: ${t[3]} × ${r} = ${s * r ** 4}`);
    }
    case "geo3": {
      const s = ri(2, 5), r = pick([2, 3, 4]);
      const t = [0, 1, 2, 3].map((i) => s * r ** i);
      return seqQ(t, s * r ** 4, `Hər ədəd əvvəlkinin ${r} mislidir: ${t[3]} × ${r} = ${s * r ** 4}`);
    }
    case "alt": {
      const s = ri(1, 15), a = ri(1, 5), b = a + ri(1, 4);
      const t = [s];
      for (let i = 0; i < 5; i++) t.push(t[i] + (i % 2 === 0 ? a : b));
      const next = t[5] + (5 % 2 === 0 ? a : b);
      const shown = t.slice(0, 6);
      return seqQ(shown, next, `Növbə ilə +${a} və +${b} əlavə olunur. Növbəti: ${t[5]} + ${b} = ${next}`);
    }
    case "mid": {
      const s = ri(1, 20), st = ri(2, 9);
      const t = [0, 1, 2, 3, 4].map((i) => s + i * st);
      const hole = ri(1, 3);
      const ans = t[hole];
      const shown = t.map((v, i) => (i === hole ? "?" : String(v)));
      return mk(cat, d, "mid", `Çatışmayan ədədi tap: ${shown.join(", ")}`, numOptions(ans, [ans + 1, ans - 1], 5), `Hər dəfə ${st} artır, çatışmayan ədəd ${ans}-dir.`);
    }
    case "fib": {
      const a = ri(1, 5), b = ri(2, 6);
      const t = [a, b];
      for (let i = 2; i < 7; i++) t.push(t[i - 1] + t[i - 2]);
      return seqQ(t.slice(0, 6), t[6], `Hər ədəd əvvəlki iki ədədin cəmidir: ${t[4]} + ${t[5]} = ${t[6]}`);
    }
    case "tri": {
      const k = ri(0, 2);
      const tn = (n: number) => (n * (n + 1)) / 2;
      const t = [1, 2, 3, 4, 5].map((n) => tn(n + k));
      return seqQ(t, tn(6 + k), `Fərqlər 1-lə artır (${t[1] - t[0]}, ${t[2] - t[1]}, ${t[3] - t[2]}, ${t[4] - t[3]}…). Növbəti fərq ${6 + k}: ${t[4]} + ${6 + k} = ${tn(6 + k)}`);
    }
    case "sqp": {
      const add = ri(0, 3);
      const f = (n: number) => n * n + add;
      const t = [1, 2, 3, 4, 5].map(f);
      return seqQ(t, f(6), `Ədədlər ${add ? `n² + ${add}` : "n²"} qaydası ilə düzülüb. Növbəti: 6² ${add ? `+ ${add} ` : ""}= ${f(6)}`);
    }
    case "odd":
    case "oddk": {
      const k = d >= 3 ? pick([6, 7, 8, 9]) : pick([2, 3, 5]);
      const suffix: Record<number, string> = { 2: "yə", 3: "ə", 5: "ə", 6: "ya", 7: "yə", 8: "ə", 9: "a" };
      const mult = sample([2, 3, 4, 5, 6, 7, 8, 9, 10, 11], 3).map((m) => m * k);
      let odd = ri(5, 60);
      while (odd % k === 0) odd = ri(5, 60);
      const opts = [String(odd), ...mult.map(String)];
      return mk(cat, d, "odd", `Aşağıdakı ədədlərdən hansı ${k}-${suffix[k]} qalıqsız bölünmür: ${shuffle(opts).join(", ")}?`, opts, `${mult.join(", ")} ədədləri ${k}-${suffix[k]} bölünür, ${odd} isə bölünmür.`);
    }
    case "time1": {
      const h = ri(1, 7), add = ri(1, 4);
      return mk(cat, 1, "time", `Saat ${h}:00-dır. ${add} saat sonra saat neçə olacaq?`, [`${h + add}:00`, `${h + add + 1}:00`, `${h + add - 1}:00`, `${h + add + 2}:00`].map((s) => s), `${h} + ${add} = ${h + add}, yəni ${h + add}:00.`);
    }
    case "time3": {
      const h = ri(8, 17), m = pick([10, 15, 20, 30, 40, 45, 50]);
      const dh = ri(1, 3), dm = pick([15, 20, 25, 35, 40, 45]);
      let tm = m + dm, th = h + dh;
      if (tm >= 60) { tm -= 60; th += 1; }
      const f = (hh: number, mm: number) => `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
      const correct = f(th, tm);
      const wrongs = Array.from(new Set([f(th, (tm + 10) % 60), f(th + 1, tm), f(th - 1, tm), f(th, (tm + 50) % 60), f(th + 1, (tm + 5) % 60)])).filter((x) => x !== correct);
      return mk(cat, 3, "time", `Film ${f(h, m)}-də başlayır və ${dh} saat ${dm} dəqiqə davam edir. Film saat neçədə bitir?`, [correct, ...shuffle(wrongs).slice(0, 3)], `${f(h, m)} + ${dh} saat = ${f(h + dh, m)}; üstəlik ${dm} dəqiqə = ${correct}`);
    }
    case "order1":
    case "order2": {
      const [A, B, C] = sample(NAMES, 3);
      const lowest = ri(0, 1) === 0;
      const q = `${A[0]} ${B[1]} hündürdür. ${B[0]} ${C[1]} hündürdür. Ən ${lowest ? "alçaq" : "hündür"} boylu kimdir?`;
      const ans = lowest ? C[0] : A[0];
      return mk(cat, d, "order", q, [ans, ...[A[0], B[0], C[0]].filter((n) => n !== ans).slice(0, 1), "Müəyyən etmək olmaz", ...[A[0], B[0], C[0]].filter((n) => n !== ans).slice(1, 2)], `Sıralama: ${A[0]} > ${B[0]} > ${C[0]} (hündürlüyə görə). Ən ${lowest ? "alçaq" : "hündür"} ${ans}-dir.`);
    }
    case "age": {
      const [A, B] = sample(NAMES, 2);
      const diff = ri(2, 9), age = ri(6, 14);
      return mk(cat, d, "age", `${A[0]} ${B[1]} ${diff} yaş böyükdür. ${B[0]} ${age} yaşındadır. ${A[0]} neçə yaşındadır?`, numOptions(age + diff, [age - diff, diff], 3), `${age} + ${diff} = ${age + diff}`);
    }
  }
  return genMath(d);
}

/* ───────────────────────── COĞRAFİYA ───────────────────────── */

// [ölkə, ölkənin yiyəlik halı, paytaxt, çətinlik, (varsa) tez-tez səhv edilən şəhər]
const CAPITALS: [string, string, string, 1 | 2 | 3, string?][] = [
  ["Türkiyə", "Türkiyənin", "Ankara", 1, "İstanbul"],
  ["Rusiya", "Rusiyanın", "Moskva", 1, "Sankt-Peterburq"],
  ["Fransa", "Fransanın", "Paris", 1],
  ["Almaniya", "Almaniyanın", "Berlin", 1],
  ["İtaliya", "İtaliyanın", "Roma", 1],
  ["Böyük Britaniya", "Böyük Britaniyanın", "London", 1],
  ["Yaponiya", "Yaponiyanın", "Tokio", 1],
  ["Çin", "Çinin", "Pekin", 2, "Şanxay"],
  ["İspaniya", "İspaniyanın", "Madrid", 2, "Barselona"],
  ["Misir", "Misirin", "Qahirə", 2],
  ["Gürcüstan", "Gürcüstanın", "Tbilisi", 2],
  ["İran", "İranın", "Tehran", 2],
  ["Yunanıstan", "Yunanıstanın", "Afina", 2],
  ["Ukrayna", "Ukraynanın", "Kiyev", 2],
  ["Polşa", "Polşanın", "Varşava", 2],
  ["Portuqaliya", "Portuqaliyanın", "Lissabon", 2],
  ["Hindistan", "Hindistanın", "Nyu-Dehli", 2, "Mumbay"],
  ["ABŞ", "ABŞ-ın", "Vaşinqton", 2, "Nyu-York"],
  ["Kanada", "Kanadanın", "Ottava", 3, "Toronto"],
  ["Avstraliya", "Avstraliyanın", "Kanberra", 3, "Sidney"],
  ["Braziliya", "Braziliyanın", "Brasilia", 3, "Rio-de-Janeyro"],
  ["Argentina", "Argentinanın", "Buenos-Ayres", 3],
  ["Qazaxıstan", "Qazaxıstanın", "Astana", 3, "Almatı"],
  ["Özbəkistan", "Özbəkistanın", "Daşkənd", 3],
  ["Türkmənistan", "Türkmənistanın", "Aşqabad", 3],
  ["Cənubi Koreya", "Cənubi Koreyanın", "Seul", 3],
  ["Norveç", "Norveçin", "Oslo", 3],
  ["İsveç", "İsveçin", "Stokholm", 3],
  ["Finlandiya", "Finlandiyanın", "Helsinki", 3],
  ["Avstriya", "Avstriyanın", "Vyana", 2],
  ["Macarıstan", "Macarıstanın", "Budapeşt", 3],
  ["Çexiya", "Çexiyanın", "Praqa", 3],
  ["Niderland", "Niderlandın", "Amsterdam", 2],
  ["Belçika", "Belçikanın", "Brüssel", 3],
  ["İsveçrə", "İsveçrənin", "Bern", 3, "Sürix"],
  ["Meksika", "Meksikanın", "Mexiko", 3],
  ["Kuba", "Kubanın", "Havana", 3],
  ["Peru", "Perunun", "Lima", 3],
  ["Çili", "Çilinin", "Santyaqo", 3],
  ["Keniya", "Keniyanın", "Nairobi", 3],
  ["Maroko", "Marokonun", "Rabat", 3, "Kasablanka"],
  ["Nigeriya", "Nigeriyanın", "Abuja", 3, "Laqos"],
  ["Tailand", "Tailandın", "Banqkok", 3],
  ["Vyetnam", "Vyetnamın", "Hanoy", 3],
  ["İndoneziya", "İndoneziyanın", "Cakarta", 3],
];

export function genGeo(d: number): Question {
  const pool = CAPITALS.filter((c) => (d <= 1 ? c[3] <= 2 : c[3] >= 2));
  const [country, gen, capital, , trap] = pick(pool.length ? pool : CAPITALS);
  const others = CAPITALS.filter((c) => c[2] !== capital);
  const reverse = Math.random() < 0.4;
  if (reverse) {
    const wrong = sample(others, 3).map((c) => c[0]);
    return mk("cografiya", d, "cap", `${capital} hansı ölkənin paytaxtıdır?`, [country, ...wrong], `${capital} — ${country} ölkəsinin paytaxtıdır.`);
  }
  const wrongCaps: string[] = [];
  if (trap && d >= 2) wrongCaps.push(trap);
  for (const c of sample(others, 4)) if (wrongCaps.length < 3 && !wrongCaps.includes(c[2])) wrongCaps.push(c[2]);
  return mk("cografiya", d, "cap", `${gen} paytaxtı hansı şəhərdir?`, [capital, ...wrongCaps], `${country} ölkəsinin paytaxtı ${capital} şəhəridir${trap ? ` (${trap} deyil)` : ""}.`);
}

/* ───────────────────────── ELM (kimyəvi elementlər) ───────────────────────── */

// [ad, simvol, çətinlik]
const ELEMENTS: [string, string, 1 | 2 | 3][] = [
  ["Hidrogen", "H", 1], ["Oksigen", "O", 1], ["Karbon", "C", 1], ["Helium", "He", 1], ["Qızıl", "Au", 2],
  ["Dəmir", "Fe", 2], ["Gümüş", "Ag", 2], ["Mis", "Cu", 2], ["Azot", "N", 2], ["Kalsium", "Ca", 2],
  ["Natrium", "Na", 2], ["Alüminium", "Al", 2], ["Kalium", "K", 3], ["Sink", "Zn", 3], ["Qurğuşun", "Pb", 3],
  ["Civə", "Hg", 3], ["Qalay", "Sn", 3], ["Maqnezium", "Mg", 3], ["Silisium", "Si", 3], ["Xlor", "Cl", 3],
  ["Kükürd", "S", 3], ["Neon", "Ne", 3],
];

export function genElement(d: number): Question {
  const pool = ELEMENTS.filter((e) => (d <= 1 ? e[2] <= 2 : e[2] >= 2));
  const [name, sym] = pick(pool);
  const others = ELEMENTS.filter((e) => e[1] !== sym);
  if (Math.random() < 0.5) {
    return mk("elm", d, "el", `${name} kimyəvi elementinin simvolu hansıdır?`, [sym, ...sample(others, 3).map((e) => e[1])], `${name} elementinin simvolu ${sym}-dir.`);
  }
  return mk("elm", d, "el", `Kimyəvi element cədvəlində “${sym}” simvolu hansı elementi bildirir?`, [name, ...sample(others, 3).map((e) => e[0])], `${sym} — ${name} elementinin simvoludur.`);
}

/* ───────────────────────── DİL (ingilis sözləri) ───────────────────────── */

// [azərbaycanca, ingiliscə, çətinlik]
const WORDS: [string, string, 1 | 2 | 3][] = [
  ["alma", "apple", 1], ["kitab", "book", 1], ["su", "water", 1], ["ev", "house", 1], ["pişik", "cat", 1], ["it", "dog", 1],
  ["günəş", "sun", 1], ["ulduz", "star", 1], ["qırmızı", "red", 1], ["mavi", "blue", 1], ["yaşıl", "green", 1], ["sarı", "yellow", 1],
  ["qara", "black", 1], ["ağ", "white", 1], ["çörək", "bread", 1], ["süd", "milk", 1], ["məktəb", "school", 1], ["müəllim", "teacher", 1],
  ["dost", "friend", 1], ["ağac", "tree", 1], ["çiçək", "flower", 1], ["quş", "bird", 1], ["balıq", "fish", 1], ["maşın", "car", 1],
  ["stol", "table", 1], ["stul", "chair", 1], ["ana", "mother", 1], ["ata", "father", 1], ["qardaş", "brother", 1], ["bacı", "sister", 1],
  ["böyük", "big", 1], ["kiçik", "small", 1], ["isti", "hot", 1], ["soyuq", "cold", 1],
  ["qapı", "door", 2], ["pəncərə", "window", 2], ["yağış", "rain", 2], ["qar", "snow", 2], ["külək", "wind", 2], ["şəhər", "city", 2],
  ["dəniz", "sea", 2], ["dağ", "mountain", 2], ["gecə", "night", 2], ["səhər", "morning", 2], ["yatmaq", "sleep", 2], ["qaçmaq", "run", 2],
  ["yazmaq", "write", 2], ["gülmək", "laugh", 2], ["asan", "easy", 2], ["kitabxana", "library", 2], ["xəstəxana", "hospital", 2],
  ["yay", "summer", 2], ["payız", "autumn", 2], ["qış", "winter", 2], ["gəmi", "ship", 2], ["qatar", "train", 2], ["təyyarə", "airplane", 2],
  ["açar", "key", 3], ["körpü", "bridge", 3], ["qanad", "wing", 3], ["həyat", "life", 3], ["sülh", "peace", 3], ["cəsur", "brave", 3],
  ["təhlükəli", "dangerous", 3], ["əhəmiyyətli", "important", 3], ["dərman", "medicine", 3], ["göy qurşağı", "rainbow", 3],
  ["ayaqqabı", "shoe", 3], ["velosiped", "bicycle", 3], ["qonaq", "guest", 3], ["çiyin", "shoulder", 3],
];

export function genWord(d: number): Question {
  const pool = WORDS.filter((w) => (d <= 1 ? w[2] <= 2 : w[2] >= 2));
  const [az, en] = pick(pool);
  const others = WORDS.filter((w) => w[1] !== en);
  if (Math.random() < 0.5) {
    return mk("dil", d, "word", `“${az}” sözünün ingiliscə qarşılığı hansıdır?`, [en, ...sample(others, 3).map((w) => w[1])], `${az} — ${en}`);
  }
  return mk("dil", d, "word", `İngilis dilində “${en}” sözü nə deməkdir?`, [az, ...sample(others, 3).map((w) => w[0])], `${en} — ${az}`);
}

export const GENERATORS: Record<string, { share: number; fn: (d: number) => Question }> = {
  riyaziyyat: { share: 0.7, fn: genMath },
  mentiq: { share: 0.5, fn: genLogic },
  cografiya: { share: 0.3, fn: genGeo },
  elm: { share: 0.2, fn: genElement },
  dil: { share: 0.35, fn: genWord },
};
