import type { Mode, PublicQuestion } from "@/lib/categories";
import type { Question, StaticQ } from "./types";
import { RIYAZIYYAT } from "./bank/riyaziyyat";
import { MENTIQ } from "./bank/mentiq";
import { COGRAFIYA } from "./bank/cografiya";
import { TARIX } from "./bank/tarix";
import { ELM } from "./bank/elm";
import { TEBIET } from "./bank/tebiet";
import { DIL } from "./bank/dil";
import { GENERATORS } from "./generators";
import { pick, shuffle } from "./util";

const RAW: Record<string, StaticQ[]> = {
  riyaziyyat: RIYAZIYYAT,
  mentiq: MENTIQ,
  cografiya: COGRAFIYA,
  tarix: TARIX,
  elm: ELM,
  tebiet: TEBIET,
  dil: DIL,
};

export const SUBJECTS = Object.keys(RAW);

function toQuestion(cat: string, s: StaticQ): Question {
  return { id: s[0], cat, d: s[1], q: s[2], o: [...s[3]], e: s[4], generated: false };
}

export const BANK: Record<string, Question[]> = Object.fromEntries(
  Object.entries(RAW).map(([cat, list]) => [cat, list.map((s) => toQuestion(cat, s))]),
);

export const ALL_STATIC: Question[] = Object.values(BANK).flat();

function allowedDifficulties(mode: Mode): number[] {
  return mode === "kids" ? [1, 2] : [2, 3];
}

export function questionQuality(q: Pick<Question, "q" | "o" | "e">): string | null {
  if (q.o.length !== 4) return "4 variant olmalıdır";
  if (new Set(q.o.map((x) => x.trim().toLowerCase())).size !== 4) return "Variantlar təkrarlanır";
  if (q.o.some((x) => !x.trim())) return "Boş variant";
  if (!q.q.trim() || !q.e.trim()) return "Boş sual/izah";
  return null;
}

export type SessionResult = {
  questions: PublicQuestion[];
  resetCats: string[];
};

export function buildSession(opts: {
  cat: string;
  mode: Mode;
  count: number;
  exclude: string[];
}): SessionResult {
  const { cat, mode, count } = opts;
  const exclude = new Set(opts.exclude);
  const diffs = allowedDifficulties(mode);
  const cats = cat === "qarisiq" ? SUBJECTS : SUBJECTS.includes(cat) ? [cat] : ["mentiq"];

  const used = new Set<string>();
  const usedText = new Set<string>();
  const resetCats = new Set<string>();
  const out: Question[] = [];

  const genDiff = () => pick(diffs);

  const takeStatic = (c: string): Question | null => {
    const base = BANK[c].filter((q) => diffs.includes(q.d) && !used.has(q.id));
    const fresh = base.filter((q) => !exclude.has(q.id));
    if (fresh.length) return pick(fresh);
    if (base.length) {
      resetCats.add(c);
      return pick(base);
    }
    return null;
  };

  const takeGen = (c: string): Question | null => {
    const g = GENERATORS[c];
    if (!g) return null;
    for (let i = 0; i < 20; i++) {
      const q = g.fn(genDiff());
      if (!usedText.has(q.q) && !questionQuality(q)) return q;
    }
    return null;
  };

  let order = shuffle(cats);
  let guard = 0;
  while (out.length < count && guard++ < 300) {
    if (out.length > 0 && out.length % order.length === 0) order = shuffle(cats);
    const c = order[out.length % order.length];
    const g = GENERATORS[c];
    let q: Question | null = null;
    const freshStatic = BANK[c].some((x) => diffs.includes(x.d) && !used.has(x.id) && !exclude.has(x.id));
    if (g && (Math.random() < g.share || !freshStatic)) q = takeGen(c);
    if (!q) q = takeStatic(c) ?? takeGen(c);
    if (!q || used.has(q.id) || usedText.has(q.q)) continue;
    used.add(q.id);
    usedText.add(q.q);
    out.push(q);
  }

  // Asan → çətin sıralama (sabit sıralama: eyni çətinlik daxilində təsadüfi)
  out.sort((a, b) => a.d - b.d);

  const questions: PublicQuestion[] = out.map((q) => {
    const shuffled = shuffle(q.o.map((text, i) => ({ text, correct: i === 0 })));
    return {
      id: q.id,
      cat: q.cat,
      d: q.d,
      q: q.q,
      options: shuffled.map((s) => s.text),
      answer: shuffled.findIndex((s) => s.correct),
      explain: q.e,
    };
  });

  return { questions, resetCats: Array.from(resetCats) };
}
