import { ALL_STATIC, BANK, buildSession, questionQuality } from "../src/lib/quiz/engine";
import { GENERATORS } from "../src/lib/quiz/generators";

let errors = 0;
const fail = (m: string) => { errors++; console.log("✗", m); };

// 1) static bank checks
const ids = new Set<string>();
const texts = new Set<string>();
for (const q of ALL_STATIC) {
  if (ids.has(q.id)) fail(`dublikat id ${q.id}`);
  ids.add(q.id);
  if (texts.has(q.q)) fail(`dublikat sual ${q.id}`);
  texts.add(q.q);
  const err = questionQuality(q);
  if (err) fail(`${q.id}: ${err}`);
  if (/[\u00AD\u0400-\u04FF]/.test(JSON.stringify(q))) fail(`${q.id}: gizli/kiril simvol`);
  // the correct option must not also appear inside the wrong ones by value
  if (q.o.slice(1).includes(q.o[0])) fail(`${q.id}: düzgün cavab səhvlər arasında`);
}
console.log("Static suallar:", ALL_STATIC.length);
for (const [c, list] of Object.entries(BANK)) {
  const by = [1, 2, 3].map((d) => list.filter((q) => q.d === d).length);
  console.log(` ${c}: asan ${by[0]}, orta ${by[1]}, çətin ${by[2]}`);
}

// 2) independent math verification of generated arithmetic
function evalCheck(q: string, correct: string): boolean | null {
  let m;
  if ((m = q.match(/^(\d+) ([+−×÷]) (\d+) = \?$/))) {
    const a = +m[1], b = +m[3];
    const r = m[2] === "+" ? a + b : m[2] === "−" ? a - b : m[2] === "×" ? a * b : a / b;
    return String(r) === correct;
  }
  if ((m = q.match(/^(\d+) ÷ (\d+) = \?$/))) return String(+m[1] / +m[2]) === correct;
  if ((m = q.match(/^(\d+) \+ (\d+) × (\d+) = \?$/))) return String(+m[1] + +m[2] * +m[3]) === correct;
  if ((m = q.match(/^\((\d+) \+ (\d+)\) × (\d+) − (\d+) = \?$/))) return String((+m[1] + +m[2]) * +m[3] - +m[4]) === correct;
  if ((m = q.match(/^(\d+) ədədinin (\d+)%-i neçədir\?$/))) return String((+m[1] * +m[2]) / 100) === correct;
  if ((m = q.match(/^(\d+)² /))) return String(+m[1] * +m[1]) === correct;
  if ((m = q.match(/^(\d+)x \+ (\d+) = (\d+) tənliyində/))) return String((+m[3] - +m[2]) / +m[1]) === correct;
  return null;
}

let genChecked = 0;
for (const [cat, g] of Object.entries(GENERATORS)) {
  for (let i = 0; i < 4000; i++) {
    const d = 1 + (i % 3);
    const q = g.fn(d);
    const err = questionQuality(q);
    if (err) { fail(`${cat} gen: ${err} :: ${q.q} :: ${q.o.join("|")}`); continue; }
    if (cat === "riyaziyyat") {
      const r = evalCheck(q.q, q.o[0]);
      if (r === false) fail(`riyaziyyat səhv: ${q.q} → ${q.o[0]}`);
      if (r === true) genChecked++;
    }
    if (q.o.some((o) => /NaN|undefined|Infinity|-\d/.test(o) && cat !== "mentiq")) fail(`${cat}: pis variant ${q.q} ${q.o}`);
    if (/undefined|NaN/.test(q.q)) fail(`${cat}: pis mətn ${q.q}`);
  }
}
console.log("Riyazi generator yoxlaması (müstəqil hesab):", genChecked, "sual");

// 3) sequences: re-derive for logic generator samples
for (let i = 0; i < 3000; i++) {
  const q = GENERATORS.mentiq.fn(1 + (i % 3));
  const m = q.q.match(/^Ardıcıllığı davam et: (.*), \?$/);
  if (m) {
    const t = m[1].split(", ").map(Number);
    const next = Number(q.o[0]);
    const diffs = t.slice(1).map((v, k) => v - t[k]);
    const arith = diffs.every((x) => x === diffs[0]) && t[t.length - 1] + diffs[0] === next;
    const ratio = t.slice(1).map((v, k) => v / t[k]);
    const geo = ratio.every((x) => x === ratio[0]) && t[t.length - 1] * ratio[0] === next;
    const fib = t.length >= 5 && t.slice(2).every((v, k) => v === t[k] + t[k + 1]) && t[t.length - 1] + t[t.length - 2] === next;
    const alt = diffs.length >= 4 && diffs.every((x, k) => x === diffs[k % 2]) && t[t.length - 1] + diffs[(diffs.length) % 2] === next;
    const sq = t.every((v, k) => { const add = t[0] - 1; return v === (k + 1) ** 2 + add; }) && ((t.length + 1) ** 2 + (t[0] - 1)) === next;
    const tri = (() => { const d2 = diffs.slice(1).map((v, k) => v - diffs[k]); return d2.every((x) => x === 1) && t[t.length - 1] + diffs[diffs.length - 1] + 1 === next; })();
    if (!(arith || geo || fib || alt || sq || tri)) fail(`ardıcıllıq qaydası tapılmadı: ${q.q} → ${q.o[0]}`);
  }
}

// 4) odd-one-out: exactly one option fails the divisibility rule
for (let i = 0; i < 2000; i++) {
  const q = GENERATORS.mentiq.fn(1 + (i % 3));
  const m = q.q.match(/hansı (\d+)-\S+ qalıqsız bölünmür/);
  if (m) {
    const k = +m[1];
    const bad = q.o.filter((o) => +o % k !== 0);
    if (bad.length !== 1 || bad[0] !== q.o[0]) fail(`odd-one-out səhv: ${q.q}`);
  }
}

// 5) session builder: no duplicates, 4 options, answer index valid, shuffle changes position
for (const cat of ["qarisiq", "riyaziyyat", "mentiq", "cografiya", "tarix", "elm", "tebiet", "dil"]) {
  for (const mode of ["kids", "adult"] as const) {
    const pos = [0, 0, 0, 0];
    for (let i = 0; i < 200; i++) {
      const s = buildSession({ cat, mode, count: 8, exclude: [] });
      if (s.questions.length !== 8) fail(`${cat}/${mode}: ${s.questions.length} sual`);
      const seen = new Set<string>();
      for (const q of s.questions) {
        if (seen.has(q.q)) fail(`${cat}/${mode}: sessiyada təkrar sual`);
        seen.add(q.q);
        if (q.options.length !== 4 || q.answer < 0 || q.answer > 3) fail(`${cat}: pis cavab indeksi`);
        pos[q.answer]++;
      }
    }
    const tot = pos.reduce((a, b) => a + b, 0);
    if (pos.some((x) => x / tot < 0.15)) fail(`${cat}/${mode}: düzgün cavab mövqeyi qeyri-bərabərdir ${pos}`);
  }
}

// 6) no-repeat rotation
{
  let seen: string[] = [];
  const all = new Set<string>();
  for (let i = 0; i < 3; i++) {
    const s = buildSession({ cat: "tarix", mode: "kids", count: 8, exclude: seen });
    const ids = s.questions.map((q) => q.id);
    if (i === 0 && ids.some((id) => seen.includes(id))) fail("təkrar");
    ids.forEach((id) => all.add(id));
    seen = [...seen, ...ids];
    console.log(` tarix/kids sessiya ${i + 1}: reset=${s.resetCats.join(",") || "yox"}`);
    if (s.resetCats.length) seen = [];
  }
}

console.log(errors ? `\n${errors} XƏTA` : "\n✔ Bütün yoxlamalar keçdi");
process.exit(errors ? 1 : 0);
